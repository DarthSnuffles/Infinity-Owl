﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to load associated imaginative exercise for a quiz topic
public class LoadImaginativeExercise : MonoBehaviour
{
    // Store contents of input field
    InputField response;

    // This procedure is run on initialisation
    void Start()
    {
        // Query database for imaginative exercise for topic
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "ie", StaticVariableHolder.topicID.ToString() };
        List<string> results = Python.RunPython(args);

        if (results[0] == "None")
        {
            // If there is no imaginative exercise (yet), skip to the Results screen
            SceneManager.LoadScene("Results");
        } else
        {
            // Otherwise, display the imaginative exercise in the UI
            GameObject.Find("ImaginativeExercise").GetComponent<Text>().text = results[0];   
        }
        // Display topic name
        GameObject.Find("TopicName").GetComponentInChildren<Text>().text = "Topic: " + StaticVariableHolder.topic;       
    }

    // Set user's response to imaginative exercise from input field
    public void SetResponse(InputField text)
    {
        response = text;
    }

    // Procedure to submit response to imaginative exercise
    public void SubmitResponse()
    {
        if (response != null && response.text != "")
        {
            // If user entered something into the input field and clicked 'Submit', set string variable for their response
            string imaginativeResponse = response.text;

            // Insert response into the database
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "ir", StaticVariableHolder.userID.ToString(), StaticVariableHolder.topicID.ToString(), "\"" + imaginativeResponse + "\""  };
            Python.RunPython(args);

            // Fade into the Results screen for the quiz
            Initiate.Fade("Results", Color.black, 4.0f);
        } else
        {
            // If they clicked 'Submit', without entering anything into the input field, display error message
            if (!EditorUtility.DisplayDialog("Error",
               "Please write something imaginative in the box! It could just be a sentence... or it could be a paragraph or poem or something else.\n(Or you can skip this exercise and view the quiz results.)",
               "OK", "Skip"))
            {
                // If they choose to skip the imaginative exercise, fade into the Results screen
                Initiate.Fade("Results", Color.black, 4.0f);
            }
        }      
    }
}
#endif