﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to display user's personal owl (image)
public class DisplayOwl : MonoBehaviour
{
    // This procedure is run on initialisation
	void Start()
	{
        // Load owl graphic from file path into UI
        WWW www = new WWW("file://C://Users//darth//Pictures//ProjectImages//OwlCartoon1.png");
        GameObject image = GameObject.Find("RawImage");
        image.GetComponent<RawImage>().texture = www.texture;
    }
}
