﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ShowResults : MonoBehaviour
{
	void Start()
	{
        GameObject.Find("TopicName").GetComponentInChildren<Text>().text = "Topic: " + StaticVariableHolder.topic;
        GameObject.Find("Results").GetComponentInChildren<Text>().text = ("Well done! You scored " + StaticVariableHolder.score.ToString() + "/10");

        WWW www = new WWW("file://C://Users//darth//Pictures//ProjectImages//OwlCartoon1.png");
        GameObject image = GameObject.Find("RawImage");
        image.GetComponent<RawImage>().texture = www.texture;
    }
}
