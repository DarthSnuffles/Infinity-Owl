﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to load inbox of received messages
public class LoadInbox : MonoBehaviour
{
    // Stores contents of input field
    public InputField messageID;

    // This procedure is run on initialisation
    void Start()
    {
        // Reset static variable for ID of message being viewed
        StaticVariableHolder.messageID = 0;
        // Initialise group filter and search strings
        string groupFilter = "None";
        string subjectSearchStr = "None";
        string senderSearchStr = "None";

        if (StaticVariableHolder.filterByGroup != null)
        {
            // If group filter was set, turn it on
            groupFilter = StaticVariableHolder.filterByGroup;
        }
        if (StaticVariableHolder.searchByTopicSubject != null)
        {
            // If subject search string was entered, search messages using it
            subjectSearchStr = StaticVariableHolder.searchByTopicSubject;
        }
        if (StaticVariableHolder.searchByUser != null)
        {
            // If sender search string was entered, search messages using it
            senderSearchStr = StaticVariableHolder.searchByUser;
        }

        // Query database for list of messages received by user
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "vi", StaticVariableHolder.userID.ToString(), groupFilter, subjectSearchStr, senderSearchStr };
        List<string> results = Python.RunPython(args);

        // Iterate through results
        for (int i = 0; i < results.Count; i++)
        {
            // Split message entry at commas
            string[] entry = results[i].Split(',');
            // Display message header, including its ID, subject and sender
            GameObject.Find("MessageIDList").GetComponent<Text>().text += "\n" + entry[0];
            GameObject.Find("MessageSubjectList").GetComponent<Text>().text += "\n" + entry[2];
            GameObject.Find("MessageSenderList").GetComponent<Text>().text += "\n" + entry[1];
        }
    }

    // Set ID of message to be viewed, from input field
    public void SetMessageID(InputField text)
    {
        messageID = text;
    }

    // Procedure to view message from entered ID
    public void ViewMessage()
    {
        try
        {
            // Set static variable for ID of message being viewed, from entered message ID
            StaticVariableHolder.messageID = Int32.Parse(messageID.text);
            // Load message into new screen
            SceneManager.LoadScene("Message");
        } catch
        {
            // If user entered an invalid input for message ID, display error message
            if (!EditorUtility.DisplayDialog("Error viewing message",
                "Invalid message ID. Please try again.",
                "OK", "Cancel"))
            {
                // If they choose to cancel, return to Messages menu
                SceneManager.LoadScene("Messages");
            }
        }
    }
}
#endif