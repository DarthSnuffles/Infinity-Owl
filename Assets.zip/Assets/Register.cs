﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to register user with an account
public class Register : MonoBehaviour
{ 
    // Store contents of input fields
    public InputField firstName;
    public InputField surname;
    public InputField username;
    public InputField password;

    // Set first name from input field
    public void SetFirstName(InputField text)
    {
        firstName = text;
    }

    // Set surname from input field
    public void SetSurname(InputField text)
    {
        surname = text;
    }

    // Set username from input field
    public void SetUsername(InputField text)
    {
        username = text;
    }

    // Set password from input field
    public void SetPassword(InputField text)
    {
        password = text;
    }

    // Function to get selected owl colour from dropdown menu
    public string GetOwlColour()
    {
        // Find dropdown menu component
        GameObject dropdownMenu = GameObject.Find("OwlColourDropdown");

        // Get index of selected option
        int index = dropdownMenu.GetComponent<Dropdown>().value;

        // Get all available options in dropdown menu
        List<Dropdown.OptionData> options = dropdownMenu.GetComponent<Dropdown>().options;

        // Get string value at selected index, and return
        return options[index].text;
    }

    // Procedure to register user to the system
    public void RegisterUser()
    {
        try
        {
            // Get user's chosen owl colour from dropdown menu
            string owlColour = GetOwlColour();

            // Try to update database, by inserting record for new user, containing their entered information
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "r", username.text, password.text, firstName.text, surname.text, owlColour };
            List<string> results = Python.RunPython(args);

            if (results[0] != "Error")
            {
                // If the database was successfully updated with the new account, return to the log-in screen
                SceneManager.LoadScene("LogIn");
            } else
            {
                // If an error occurred when trying to register (because username is already taken), display error message
                if (!EditorUtility.DisplayDialog("Error",
               "Sorry, that username has been taken.\nPlease try another one.",
               "OK", "Cancel"))
                {
                    // If user cancels registration process, load log-in screen again
                    SceneManager.LoadScene("LogIn");
                }
            }
            
        } catch
        {
            // If user entered an invalid input for any of their details, display error message
            if (!EditorUtility.DisplayDialog("Error",
               "Sorry, we could not register you.\nPlease check your details and try again.",
               "OK", "Cancel"))
            {
                // If user cancels registration process, load log-in screen again
                SceneManager.LoadScene("LogIn");
            }
        }
    }
}
#endif
