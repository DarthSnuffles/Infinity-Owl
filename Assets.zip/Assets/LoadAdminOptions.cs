﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to load group admin options
public class LoadAdminOptions : MonoBehaviour
{
    // Store category and deadline of topic to be unlocked
    string category;
    InputField deadline;

    // This procedure is run on initialisation
    void Start()
    {
        // Display name of group
        GameObject.Find("AdminOptionsTitle").GetComponent<Text>().text = "Admin Options for Group: " + StaticVariableHolder.groupOptions;
    }

    // Procedure to fill category and topic dropdown menus
    public void FillTopicsDropdown()
    {
        // Find category dropdown menu component
        Dropdown categoryDropdown = GameObject.Find("CategoryDropdown").GetComponent<Dropdown>();

        // Get index of selected option
        int index = categoryDropdown.value;

        // Get all available options in dropdown menu
        List<Dropdown.OptionData> options = categoryDropdown.options;

        // Get string value at selected index, and assign to variable
        if (options[index].text != null)
        {
            category = options[index].text;
        }

        if (category != "None")
        {
            // If category has been selected, find topic dropdown menu component
            Dropdown topicDropdown = GameObject.Find("TopicDropdown").GetComponent<Dropdown>();
            // Initialise empty list of topics
            List<string> topics = new List<string> { "None" };

            // Query database for topics belonging to selected category
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "f", category };
            List<string> results = Python.RunPython(args);

            // Iterate through results
            for (int i = 0; i < results.Count; i++)
            {
                // Add topic name to list
                topics.Add(results[i]);
            }

            // Add options to topic dropdown menu, from list of topics in selected category
            topicDropdown.ClearOptions();
            topicDropdown.AddOptions(topics);
        }
    }

    // Set deadline for quiz unlock from input field
    public void SetDeadline(InputField text)
    {
        deadline = text;
    }

    // Procedure to unlock chosen quiz topic for the group
    public void UnlockQuiz()
    {
        try
        {
            // Try to parse the deadline (it must be in the correct date format)
            DateTime deadlineDate = DateTime.Parse(deadline.text);
            string.Format("{0:d/MM/yyyy}", deadlineDate);

            // Initialise variable for topic to be unlocked
            string topic = "None";

            // Find topic dropdown menu component
            GameObject dropdownMenu = GameObject.Find("TopicDropdown");

            // Get index of selected option
            int index = dropdownMenu.GetComponent<Dropdown>().value;

            // Get all available options in dropdown menu
            List<Dropdown.OptionData> options = dropdownMenu.GetComponent<Dropdown>().options;

            // Get string value at selected index, and assign to variable
            if (options[index].text != null)
            {
                topic = options[index].text;
            }

            if (topic != "None")
            {
                // If a topic has been chosen to be unlocked, update entry for group in database with the unlocked topic
                string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "uq", "\"" + StaticVariableHolder.groupOptions + "\"", "\"" + topic + "\"", deadline.text };
                Python.RunPython(args);

                // Return to list of groups the user belongs to
                SceneManager.LoadScene("MyGroups");
            }
            else
            {
                // If no topic was chosen, display error message
                if (!EditorUtility.DisplayDialog("Error unlocking quiz",
                    "Please select a quiz to unlock for this group.",
                    "OK", "Cancel"))
                {
                    // If the user cancels, return to list of their groups
                    SceneManager.LoadScene("MyGroups");
                }
            }
        } catch
        {
            // If user entered the deadline in an invalid format, display error message
            if (!EditorUtility.DisplayDialog("Error unlocking quiz",
                    "Please enter a valid date for the quiz to be unlocked until, in the format DD/MM/YYYY.",
                    "OK", "Cancel"))
            {
                // If the user cancels, return to list of their groups
                SceneManager.LoadScene("MyGroups");
            }
        }
        
    }
}
#endif