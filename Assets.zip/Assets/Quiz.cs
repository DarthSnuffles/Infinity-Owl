﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Quiz : MonoBehaviour
{
	public void StartQuiz(int buttonNum)
	{
        var topicMenu = GameObject.Find("TopicList").GetComponent<Canvas>();
        string topicName = topicMenu.GetComponentsInChildren<Button>()[buttonNum - 1].GetComponentInChildren<Text>().text;

        StaticVariableHolder.topic = topicName;
        StaticVariableHolder.questionNum = 1;

        Initiate.Fade("Quiz", Color.black, 2.0f);
	}

    public void NextQuestion(int answerNum)
    {
        string answer = GameObject.Find("Answer" + answerNum.ToString()).GetComponentInChildren<Text>().text;
        if (answer == StaticVariableHolder.correctAnswer)
        {
            StaticVariableHolder.score += 1;
        }

        if (StaticVariableHolder.questionNum == 10)
        {
            Initiate.Fade("Results", Color.black, 2.0f);
        }
        else
        {
            StaticVariableHolder.questionNum += 1;
            SceneManager.LoadScene("Quiz");
        }
    }
}
