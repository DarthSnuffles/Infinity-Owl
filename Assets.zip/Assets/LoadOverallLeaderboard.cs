﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to load overall leaderboard of users
public class LoadOverallLeaderboard : MonoBehaviour
{
    // This procedure is run on initialisation
    void Start()
    {
        if (StaticVariableHolder.filterByGroup == null)
        {
            // If group filter is not on, query database for default leaderboard (sorted by descending level/XP)
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "l" };
            List<string> results = Python.RunPython(args);

            // Iterate through results
            for (int i = 0; i < results.Count; i++)
            {
                // Split leaderboard entry for a user at the commas
                string[] entry = results[i].Split(',');
                // Display leaderboard entry, including position, username, XP and level
                GameObject.Find("PositionLeaderboard").GetComponent<Text>().text += "\n" + entry[0];
                GameObject.Find("UserLeaderboard").GetComponent<Text>().text += "\n" + entry[1];
                GameObject.Find("XPLeaderboard").GetComponent<Text>().text += "\n" + entry[2];
                GameObject.Find("LevelLeaderboard").GetComponent<Text>().text += "\n" + entry[3];          
            }
        } else
        {
            // Otherwise, if group filter is on, query database for leaderboard for selected group (sorted by descending level/XP)
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "lg", "\"" + StaticVariableHolder.filterByGroup + "\"" };
            List<string> results = Python.RunPython(args);

            // Iterate through results
            for (int i = 0; i < results.Count; i++)
            {
                // Split leaderboard entry for a user at commas
                string[] entry = results[i].Split(',');
                // Display leaderboard entry, including position, username, XP and level
                GameObject.Find("PositionLeaderboard").GetComponent<Text>().text += "\n" + entry[0];
                GameObject.Find("UserLeaderboard").GetComponent<Text>().text += "\n" + entry[1];
                GameObject.Find("XPLeaderboard").GetComponent<Text>().text += "\n" + entry[2];
                GameObject.Find("LevelLeaderboard").GetComponent<Text>().text += "\n" + entry[3];
            }
        }

        // Find group dropdown menu, and initialise empty list
        Dropdown groupDropdown = GameObject.Find("GroupDropdown").GetComponent<Dropdown>();
        List<string> myGroups = new List<string> { "None" };

        // Query database for groups the user belongs to
        string[] args2 = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "lmg", StaticVariableHolder.userID.ToString() };
        List<string> results2 = Python.RunPython(args2);

        // Iterate through results
        for (int i = 0; i < results2.Count; i++)
        {
            // Split entry for group at commas
            string[] entry = results2[i].Split(',');
            myGroups.Add(entry[1]);
        }

        // Add groups to list
        groupDropdown.ClearOptions();
        groupDropdown.AddOptions(myGroups);
    }

    // Procedure to filter overall leaderboard by group
    public void GroupFilter()
    {
        // Find dropdown menu component
        GameObject dropdownMenu = GameObject.Find("GroupDropdown");

        // Get index of selected option
        int index = dropdownMenu.GetComponent<Dropdown>().value;

        // Get all available options in dropdown menu
        List<Dropdown.OptionData> options = dropdownMenu.GetComponent<Dropdown>().options;

        // Get string value at selected index
        if (options[index].text != "None")
        {
            // If a group was selected, set group filter and load overall leaderboard
            StaticVariableHolder.filterByGroup = options[index].text;
            SceneManager.LoadScene("OverallLeaderboard");
        } else
        {
            // Otherwise, no group selected so display error message
            if (!EditorUtility.DisplayDialog("Error filtering leaderboard",
                        "Please select a group, or create/join one if you are not a member of any groups.",
                        "OK", "Create/Join Groups"))
            {
                // If they choose to create or join groups, load the Groups menu
                Initiate.Fade("Groups", Color.black, 4.0f);
            }
        }
    }
}
#endif