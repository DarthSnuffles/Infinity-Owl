﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to load the main menu
public class LoadMainMenu : MonoBehaviour
{
    // This procedure is run on initialisation
    void Start()
    {
        // Display username for account which is logged-in
        GameObject.Find("UsernameAndID").GetComponent<Text>().text = "Logged in as: " + StaticVariableHolder.username;
        // Initialise static variables to be used globally
        StaticVariableHolder.topicID = 0;
        StaticVariableHolder.topic = null;
        StaticVariableHolder.questionNum = 0;
        StaticVariableHolder.correctAnswer = null;
        StaticVariableHolder.score = 0;
        StaticVariableHolder.filterByGroup = null;
        StaticVariableHolder.filterByCategory = null;
        StaticVariableHolder.filterByDifficulty = null;
        StaticVariableHolder.searchByTopicSubject = null;
        StaticVariableHolder.searchByUser = null;
        StaticVariableHolder.groupOptions = null;
        StaticVariableHolder.messageID = 0;
        StaticVariableHolder.custom = false;
        // Get unlocked topics for groups
        GetGroupUnlocks();
    }

    // Procedure to get additionally unlocked topics for groups the user belongs to
    public void GetGroupUnlocks()
    {
        try
        {
            // Initialise empty list of unlocked topics for groups
            StaticVariableHolder.groupUnlocks = new List<string>();

            // Query database for groups the user belongs to
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "lmg", StaticVariableHolder.userID.ToString() };
            List<string> results = Python.RunPython(args);

            // Initialise empty list for groups the user belongs to
            List<string> myGroups = new List<string>();

            // Iterate through results
            for (int i = 0; i < results.Count; i++)
            {
                // Split entry for group at commas
                string[] entry = results[i].Split(',');
                myGroups.Add(entry[1]);
            }

            // Iterate through each group the user belongs to
            foreach (string group in myGroups)
            {
                // Check deadline for group unlock (if there is one) has not been passed, and reset if it has
                string[] args2 = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "cu", group };
                Python.RunPython(args2);

                // Query database for unlocked topic for group
                string[] args3 = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "gu", group };
                results = Python.RunPython(args3);

                if (results[0] != "None")
                {
                    // If a topic was unlocked by the group admin, add it to list of unlocked topics
                    StaticVariableHolder.groupUnlocks.Add(results[0]);
                }
            }
        } catch {
        }     
    }
}
