﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to log-in to the system
public class LogIn : MonoBehaviour
{
    // Store contents of input fields
    public InputField username;
    public InputField password;

    // Set username from input field
    public void SetUsername(InputField text)
    {
        username = text;
    }

    // Set password from input field
    public void SetPassword(InputField text)
    {
        password = text;
    }

    // Procedure to check user's entered log-in details, and transfer them to the main menu if successful
    public void LogInCheck()
    {
        try
        {
            // Query database to check if user account exists with entered username and password
            string[] args = {"\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "u", username.text, password.text};
            List<string> results = Python.RunPython(args);

            if (results != null)
            {
                // If correct log-in details, set static variables for username, user ID, first name and surname,
                // to be used throughout the application
                StaticVariableHolder.username = username.text;
                StaticVariableHolder.userID = Int32.Parse(results[0]);
                StaticVariableHolder.firstName = results[1];
                StaticVariableHolder.surname = results[2];
                // Load the main menu
                SceneManager.LoadScene("MainMenu");
            }
        } catch
        {
            // If incorrect or invalid log-in details, display error message
            if (!EditorUtility.DisplayDialog("Error logging in",
               "Incorrect username or password. Please try again.",
               "OK", "Register"))
            {
                // If user chooses to register an account, load the registration screen
                SceneManager.LoadScene("Register");
            }
        }
    }
}
#endif
