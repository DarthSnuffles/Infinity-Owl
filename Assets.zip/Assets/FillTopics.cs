﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to fill sample topic menu, so the user can choose a quiz to play
public class FillTopics : MonoBehaviour
{
    // Procedure to write topic names onto the menu buttons for a given category (Astronomy, Physics, Chemistry, Biology, Geography or History)
    public void WriteTopics(string category)
    {
        // Query database for user's level
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "mp", StaticVariableHolder.userID.ToString() };
        List<string> results = Python.RunPython(args);
        int level = Int32.Parse(results[0]);

        // Query database for topic names, belonging to given category
        string[] args2 = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "f", "\"" + category + "\""};
        results = Python.RunPython(args2);

        // Find topic menu component, and array of buttons belonging to it
        var topicMenu = GameObject.Find("TopicList").GetComponent<Canvas>();
        Button[] buttons = topicMenu.GetComponentsInChildren<Button>();

        // Iterate through buttons on topic menu
        for (int i = 0; i < buttons.Length; i++)
        {
            // Set button not to be interactable to start with...
            buttons[i].interactable = false;
            // Set text of button to display corresponding topic name
            buttons[i].GetComponentInChildren<Text>().text = results[i];
            // Set button colour to be grey initially
            var newColorBlock = buttons[i].colors;
            newColorBlock.disabledColor = Color.grey;
            buttons[i].colors = newColorBlock;

            if (level > i || (StaticVariableHolder.groupUnlocks.Contains(results[i])))
            { 
                // If user's level is high enough or the topic has been unlocked by a group admin, make button interactable (colour will be changed)
                buttons[i].interactable = true;
            }
        }
    }
}
