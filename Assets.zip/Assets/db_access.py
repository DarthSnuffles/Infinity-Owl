#!/usr/bin/python
import sys
import MySQLdb

# Open connection to database
db = MySQLdb.connect(host="localhost",    # Host
                     user="master",       # Username
                     passwd="toclafane",  # Password
                     db="infinityowldb")    # Database Name

# Create cursor object to execute queries
cur = db.cursor()

# Execute query
if sys.argv[1] == "u":
	cur.execute("SELECT username, password FROM users WHERE username='" + sys.argv[2]
				+ "' AND password='" + sys.argv[3] + "';")
	# Output query results
elif sys.argv[1] == "t":
	cur.execute("SELECT topicname FROM topics WHERE category='" + sys.argv[2] + "';")
	# Output query results
elif sys.argv[1] == 'q':
	cur.execute("SELECT topicid FROM topics WHERE topicname='" + sys.argv[2] + "';")
	for row in cur.fetchall():
		topic_id = row[0]
	cur.execute("SELECT question, answer1, answer2, answer3, correctanswer, imagepath " +
	"FROM questions WHERE topicid=" + str(topic_id) + " AND questionnum=" + sys.argv[3] + ";")

for row in cur.fetchall():
	for i in range(0, len(row)):
		print row[i]
		
# Close connection to database
db.close()