﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class StaticVariableHolder : MonoBehaviour
{
    public static string topic;
    public static int questionNum;
    public static string correctAnswer;
    public static int score;

    private void Start()
    {
        topic = null;
        questionNum = 0;
        score = 0;
        DontDestroyOnLoad(gameObject);
    }

    void Update()
    {

    }
}

