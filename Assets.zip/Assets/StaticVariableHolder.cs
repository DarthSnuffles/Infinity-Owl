﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to store static variables to be used globally
public class StaticVariableHolder : MonoBehaviour
{
    // Static variables
    public static int userID;
    public static string username;
    public static string firstName;
    public static string surname;
    public static int topicID;
    public static string topic;
    public static int questionNum;
    public static string correctAnswer;
    public static int score;
    public static string filterByGroup;
    public static string filterByCategory;
    public static string filterByDifficulty;
    public static string searchByTopicSubject;
    public static string searchByUser;
    public static string groupOptions;
    public static List<string> groupUnlocks;
    public static int messageID;
    public static Boolean custom;
    public static string[][] quiz = new string[10][];

    // This procedure is run on initialisation of object, to set up static variables
    private void Start()
    {
        // Initialise static variables
        userID = 0;
        username = null;
        firstName = null;
        surname = null;
        topicID = 0;
        topic = null;
        questionNum = 0;
        score = 0;
        filterByGroup = null;
        filterByCategory = null;
        filterByDifficulty = null;
        searchByTopicSubject = null;
        searchByUser = null;
        groupOptions = null;
        groupUnlocks = null;
        messageID = 0;
        custom = false;
        // Don't destroy this object when the scene is changed
        DontDestroyOnLoad(gameObject);
    }
}

