﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to load quiz question into UI
public class LoadQuizQuestion : MonoBehaviour
{
    // This procedure is run on initialisation
    IEnumerator Start()
    {
        // Store results of SQL query
        List<string> results = null;

        if (StaticVariableHolder.custom == false)
        {
            // If this is a sample quiz (not a custom one), query the database for current question, from the topic ID and question number
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "q", StaticVariableHolder.topicID.ToString(), StaticVariableHolder.questionNum.ToString() };
            results = Python.RunPython(args);
        }
        else
        {
            // Otherwise, if this is a custom quiz, query a different database table for current question, from the topic ID and question number
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "cq", StaticVariableHolder.topicID.ToString(), StaticVariableHolder.questionNum.ToString() };
            results = Python.RunPython(args);
        }

        // Display topic name and question number
        GameObject.Find("TopicName").GetComponentInChildren<Text>().text = "Topic: " + StaticVariableHolder.topic;
        GameObject.Find("QuestionNum").GetComponentInChildren<Text>().text = "Question " + StaticVariableHolder.questionNum.ToString() + "/10";

        // Display question and possible answers
        GameObject.Find("Question").GetComponent<Text>().text = results[0];
        GameObject.Find("Answer1").GetComponentInChildren<Text>().text = results[1];
        GameObject.Find("Answer2").GetComponentInChildren<Text>().text = results[2];
        GameObject.Find("Answer3").GetComponentInChildren<Text>().text = results[3];

        // Set static variable to correct answer
        StaticVariableHolder.correctAnswer = results[4];

        if (StaticVariableHolder.custom == false)
        {
            // If this is not a custom quiz, load image from file path
            WWW www = new WWW(results[5]);
            RawImage image = GameObject.Find("Mask").GetComponentInChildren<RawImage>();
            image.GetComponent<RawImage>().texture = www.texture;
        }
        else
        {
            // If this is a custom quiz, load image from web address (URL)
            WWW www = new WWW(results[5]);
            while (!www.isDone)
                yield return null;
            RawImage image = GameObject.Find("Mask").GetComponentInChildren<RawImage>();
            image.GetComponent<RawImage>().texture = www.texture;
        }
    }
}
#endif