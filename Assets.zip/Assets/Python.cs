﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to call the back-end Python programs from the front-end C# scripts
public class Python : MonoBehaviour
{ 
    // Procedure to run Python with arguments
    public static List<string> RunPython(string[] args)
    {
        // Initialise list to store output from Python program
        List<string> results = new List<string>();
        try
        {
            // Set file name of Python process
            ProcessStartInfo start = new ProcessStartInfo()
            {
                FileName = "C:\\Python27\\python.exe"
            };

            // Set arguments for Python process, depending on how many were provided...
            if (args.Length == 2)
            {
                start.Arguments = string.Format("{0} {1}", args[0], args[1]);
            }
            else if (args.Length == 3)
            {
                start.Arguments = string.Format("{0} {1} {2}", args[0], args[1], args[2]);
            }
            else if (args.Length == 4)
            {
                start.Arguments = string.Format("{0} {1} {2} {3}", args[0], args[1], args[2], args[3]);
            }
            else if (args.Length == 5)
            {
                start.Arguments = string.Format("{0} {1} {2} {3} {4}", args[0], args[1], args[2], args[3], args[4]);
            }
            else if (args.Length == 6)
            {
                start.Arguments = string.Format("{0} {1} {2} {3} {4} {5}", args[0], args[1], args[2], args[3], args[4], args[5]);
            }
            else if (args.Length == 7)
            {
                start.Arguments = string.Format("{0} {1} {2} {3} {4} {5} {6}", args[0], args[1], args[2], args[3], args[4], args[5], args[6]);
            }
            else if (args.Length == 8)
            {
                start.Arguments = string.Format("{0} {1} {2} {3} {4} {5} {6} {7}", args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7]);
            }
            else if (args.Length == 9)
            {
                start.Arguments = string.Format("{0} {1} {2} {3} {4} {5} {6} {7} {8}", args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8]);
            }
            else if (args.Length == 10)
            {
                start.Arguments = string.Format("{0} {1} {2} {3} {4} {5} {6} {7} {8} {9}", args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9]);
            }

            start.UseShellExecute = false;// Do not use OS shell
            start.CreateNoWindow = true; // Do not create new window
            start.RedirectStandardOutput = true;// Redirect standard output back to main application

            // Start Python process with arguments, and read output stream into list (line by line)
            using (Process process = Process.Start(start))
            {
                using (StreamReader reader = process.StandardOutput)
                {
                    while (!reader.EndOfStream)
                    {
                        results.Add(reader.ReadLine());
                    }
                }
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e.ToString());
        }
        // Return output from Python program
        return results;
    }
}
