﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScreen : MonoBehaviour
{

    public void ChangeScene(string newScene)
    {
        Initiate.Fade(newScene, Color.black, 2.0f);
    }

    // Update is called once per frame
    void Update () {
		
	}
}
