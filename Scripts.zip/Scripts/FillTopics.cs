﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class FillTopics : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void WriteTopics(bool category)
    {
        if (GameObject.Find("Topic1").GetComponentInChildren<Button>().GetComponentInChildren<Text>().text != null)
               GameObject.Find("Topic1").GetComponentInChildren<Button>().GetComponentInChildren<Text>().text = "Button 1";
        //button.interactable = true;

        var topicMenu = GameObject.Find("TopicList").GetComponent<Canvas>();
        Button[] buttons = topicMenu.GetComponentsInChildren<Button>();

        if (category)
        {
            for (int i = 0; i < buttons.Length; i++)
            {
                buttons[i].GetComponentInChildren<Text>().text = "Topic " + (i+1).ToString();
                buttons[i].interactable = true;
            }
        }
        else
        {
            for (int i = 0; i < buttons.Length; i++)
            {
                buttons[i].GetComponentInChildren<Text>().text = "Topic " + (i+1).ToString();
                buttons[i].interactable = true;
            }
        }
    }
}
