#!/usr/bin/python
import sys
import MySQLdb

db = MySQLdb.connect(host="localhost",    # your host
                     user="master",         # your username
                     passwd="toclafane",  # your password
                     db="infinityowl")        # name of the data base

# Create cursor object to execute queries
cur = db.cursor()

cur.execute("SELECT * FROM users WHERE username='" + sys.argv[1]
            + "' AND password='" + sys.argv[2] + "';")

for row in cur.fetchall():
    print row[1]
    print row[2]

db.close()
