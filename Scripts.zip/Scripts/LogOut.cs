﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LogOut : MonoBehaviour {

    public void ChangeScene(string newScene)
    {
        SceneManager.LoadScene(newScene);
    }

    // Update is called once per frame
    void Update () {
		
	}
}
