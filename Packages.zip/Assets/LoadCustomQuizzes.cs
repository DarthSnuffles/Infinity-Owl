﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to load list of custom quizzes
public class LoadCustomQuizzes : MonoBehaviour
{
    // Store contents of input field
    public InputField topicID;

    // This procedure is run on initialisation
    void Start()
    {
        // Initialise group filter and search strings
        string groupFilter = "None";
        string topicSearchStr = "None";
        string uploaderSearchStr = "None";

        if (StaticVariableHolder.filterByGroup != null)
        {
            // If group filter was set, turn it on
            groupFilter = StaticVariableHolder.filterByGroup;
        }
        if (StaticVariableHolder.searchByTopicSubject != null)
        {
            // If topic search string was entered, search custom quizzes using it
            topicSearchStr = StaticVariableHolder.searchByTopicSubject;
        }
        if (StaticVariableHolder.searchByUser != null)
        {
            // If uploader search string was entered, search custom quizzes using it
            uploaderSearchStr = StaticVariableHolder.searchByUser;
        }

        // Query database for list of custom quizzes uploaded to the community
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "lcq", groupFilter, topicSearchStr, uploaderSearchStr };
        List<string> results = Python.RunPython(args);

        // Iterate through results
        for (int i = 0; i < results.Count; i++)
        {
            // Split entry for custom quiz at commas
            string[] entry = results[i].Split(',');
            // Display custom quiz details, including its topic ID, topic name and uploader
            GameObject.Find("TopicIDList").GetComponent<Text>().text += "\n" + entry[0];
            GameObject.Find("TopicNameList").GetComponent<Text>().text += "\n" + entry[1];
            GameObject.Find("UploaderList").GetComponent<Text>().text += "\n" + entry[2];
        }
    }

    // Set ID of custom topic to be played
    public void SetTopicID(InputField text)
    {
        topicID = text;
    }
}
