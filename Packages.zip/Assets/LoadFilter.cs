﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to filter the leaderboard
public class LoadFilter : MonoBehaviour
{
    // This procedure is run on initialisation
    void Start()
    {
        // Initialise static variables for filters
        StaticVariableHolder.filterByGroup = null;
        StaticVariableHolder.filterByCategory = null;
        StaticVariableHolder.filterByDifficulty = null;

        // Find group dropdown menu
        Dropdown groupDropdown = GameObject.Find("GroupDropdown").GetComponent<Dropdown>();
        // Initialise empty list of groups
        List<string> myGroups = new List<string> { "None" };

        // Query database for groups the user belongs to
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "lmg", StaticVariableHolder.userID.ToString() };
        List<string> results = Python.RunPython(args);

        // Iterate through results
        for (int i = 0; i < results.Count; i++) {
            // Split entry for group at commas
            string[] entry = results[i].Split(',');
            // Add group name to list
            myGroups.Add(entry[1]);    
        }

        // Add options to groups dropdown menu
        groupDropdown.ClearOptions();
        groupDropdown.AddOptions(myGroups);
    }

    // Procedure to set group filter, from user's dropdown menu selection
    public void SetGroupFilter()
    {
        // Find group dropdown menu component
        GameObject dropdownMenu = GameObject.Find("GroupDropdown");

        // Get index of selected option
        int index = dropdownMenu.GetComponent<Dropdown>().value;

        // Get all available options in dropdown menu
        List<Dropdown.OptionData> options = dropdownMenu.GetComponent<Dropdown>().options;

        // Get string value at selected index, and assign to group filter
        if (options[index].text != null)
        {
            StaticVariableHolder.filterByGroup = options[index].text;
        }
    }

    // Procedure to set category filter, from user's dropdown menu selection
    public void SetCategoryFilter()
    {
        // Find category dropdown menu component
        GameObject dropdownMenu = GameObject.Find("CategoryDropdown");

        // Get index of selected option
        int index = dropdownMenu.GetComponent<Dropdown>().value;

        // Get all available options in dropdown menu
        List<Dropdown.OptionData> options = dropdownMenu.GetComponent<Dropdown>().options;

        // Get string value at selected index, and assign to category filter
        if (options[index].text != null)
        {
            StaticVariableHolder.filterByCategory = options[index].text;
        }
    }

    // Procedure to set difficulty filter, from user's dropdown menu selection
    public void SetDifficultyFilter()
    {
        // Find difficulty dropdown menu component
        GameObject dropdownMenu = GameObject.Find("DifficultyDropdown");

        // Get index of selected option
        int index = dropdownMenu.GetComponent<Dropdown>().value;

        // Get all available options in dropdown menu
        List<Dropdown.OptionData> options = dropdownMenu.GetComponent<Dropdown>().options;

        // Get string value at selected index, and assign to difficulty filter
        if (options[index].text != null)
        {
            StaticVariableHolder.filterByDifficulty = options[index].text;
        }
    }

    // Procedure to return to the overall leaderboard, without filtering
    public void ReturnToOverallLeaderboard()
    {
        // Clear group filter
        StaticVariableHolder.filterByGroup = null;
        // Fade into overall leaderboard of users
        Initiate.Fade("OverallLeaderboard", Color.black, 4.0f);
    }
}
