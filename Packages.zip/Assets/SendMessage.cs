﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to send a message to another user / group of users
public class SendMessage : MonoBehaviour
{
    // Store contents of input fields
    public InputField messageSubject;
    public InputField receiverUsers;
    public InputField messageText;

    // This procedure is run on initialisation of object
    void Start()
    {
        // Find dropdown menu for group to receive message
        Dropdown groupDropdown = GameObject.Find("ReceiverGroup").GetComponent<Dropdown>();
        // Initialise empty list of groups the user belongs to
        List<string> myGroups = new List<string> { "None" };

        // Query database for groups the user belongs to
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "lmg", StaticVariableHolder.userID.ToString() };
        List<string> results = Python.RunPython(args);

        // For each group, add its name to the list of groups
        for (int i = 0; i < results.Count; i++)
        {
            string[] entry = results[i].Split(',');
            myGroups.Add(entry[1]);
        }

        // Add group names to dropdown menu
        groupDropdown.ClearOptions();
        groupDropdown.AddOptions(myGroups);
    }

    // Set message subject from input field
    public void SetMessageSubject(InputField text)
    {
        messageSubject = text;
    }

    // Set receiver usernames from input field
    public void SetReceiverUsers(InputField text)
    {
        receiverUsers = text;
    }

    // Set message text from input field
    public void SetMessageText(InputField text)
    {
        messageText = text;
    }

    // Function to get group to receive message from dropdown menu
    public string GetReceiverGroup()
    {
        // Find dropdown menu
        GameObject dropdownMenu = GameObject.Find("ReceiverGroup");

        // Get index of selected option
        int index = dropdownMenu.GetComponent<Dropdown>().value;

        // Get all available options in dropdown menu
        List<Dropdown.OptionData> options = dropdownMenu.GetComponent<Dropdown>().options;

        // Get string value at selected index, and return
        return options[index].text;
    }

    // Procedure to send message
    public void Send()
    {
        // Get group to receive message from dropdown menu (if a group has been selected)
        string receiverGroup = GetReceiverGroup();

        string[] args = new string[3];
        // If the user has entered all the required information for the message...
        if (messageSubject != null && (receiverUsers != null || receiverGroup != "None") && messageText != null)
        {
            string receiverUserIDs = "";
            if (receiverUsers != null)
            {
                // Separate receiver usernames into array (dividing the string at the commas)
                string[] receiverUsersList = receiverUsers.text.Split(',');
                // Iterate through receiver usernames
                for (int i = 0; i < receiverUsersList.Length; i++)
                {
                    try
                    {
                        // Query database to check that a user exists with the given username
                        // If user does exist, append their ID to string (of receivers)
                        args[0] = "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"";
                        args[1] = "uid";
                        args[2] = "\"" + receiverUsersList[i] + "\"";
                        List<string> results = Python.RunPython(args);
                        if (results[0] != "None")
                        {
                            receiverUserIDs += results[0] + ",";
                        }
                    }
                    catch
                    {
                        // If user does not exist, display warning message
                        // User may send the message anyway, or check the usernames they entered
                        if (!EditorUtility.DisplayDialog("Warning",
                            "Warning: one or more of those users does not exist.",
                            "Send anyway", "Check usernames"))
                        {
                            return;
                        }
                    }
                }
            }
            string receiverGroupID = "";
            // If user selected a group to send message to...
            if (receiverGroup != "None")
            {
                try
                {
                    // Query database to check that a group exists with the given name
                    // If group does exist, store its ID in variable
                    args[0] = "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"";
                    args[1] = "gid";
                    args[2] = "\"" + receiverGroup + "\"";
                    List<string> results = Python.RunPython(args);
                    if (results[0] != "None")
                    {
                        receiverGroupID = results[0];
                    }
                } catch
                {
                    // If group does not exist, display warning message
                    if (!EditorUtility.DisplayDialog("Warning",
                            "Warning: that group does not exist.",
                            "Send anyway", "Check group name"))
                    {
                        return;
                    }
                }   
            }

            // Combine strings of receiver group IDs and user IDs
            string receivers = receiverGroupID + ":" + receiverUserIDs;
            // Update database to send message, so it can be viewed by receivers
            string[] args2 = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "sm", StaticVariableHolder.userID.ToString(), "\"" + receivers + "\"", "\"" + messageSubject.text + "\"", "\"" + messageText.text + "\"" };
            Python.RunPython(args2);

            // Fade out of scene, and back into Messages menu
            Initiate.Fade("Messages", Color.black, 4.0f);
        }
    }
}
#endif