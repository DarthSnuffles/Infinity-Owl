﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Class to exit the system
public class Exit : MonoBehaviour {
	// This procedure is run on initialisation
	public void QuitProgram () {
        // Exit the application
        Application.Quit();
	}
}
