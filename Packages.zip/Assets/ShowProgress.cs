﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to display user's progress
public class ShowProgress : MonoBehaviour
{
    // This procedure is run on initialisation of object
	void Start()
	{
        // Query database for user's progress (level and XP)
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "mp", StaticVariableHolder.userID.ToString() };
        List<string> results = Python.RunPython(args);

        // Show user's level and XP on progress screen
        GameObject.Find("Level").GetComponentInChildren<Text>().text = "Level " + results[0];
        GameObject.Find("XP").GetComponentInChildren<Text>().text = results[1] + " XP";

        // Load owl image
        WWW www = new WWW("file://C://Users//darth//Pictures//ProjectImages//OwlCartoon1.png");
        GameObject image = GameObject.Find("RawImage");
        image.GetComponent<RawImage>().texture = www.texture;
    }

    // Function to get selection from dropdown menu, if user chooses to customise owl's colour
    public string GetOwlColour()
    {
        // Find dropdown menu component
        GameObject dropdownMenu = GameObject.Find("OwlColourDropdown");

        // Get index of selected option
        int index = dropdownMenu.GetComponent<Dropdown>().value;

        // Get all available options in dropdown menu
        List<Dropdown.OptionData> options = dropdownMenu.GetComponent<Dropdown>().options;

        // Get string value at selected index, and return
        return options[index].text;
    }

    // Procedure to change user's owl colour (customisation option)
    public void changeOwlColour()
    {
        // Get chosen owl colour
        string owlColour = GetOwlColour();

        // Update user's profile in database with new owl colour
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "cc", StaticVariableHolder.userID.ToString(), owlColour };
        Python.RunPython(args);
    }
}
