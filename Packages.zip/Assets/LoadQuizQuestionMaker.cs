﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to load screen for entering a custom quiz question
public class LoadQuizQuestionMaker : MonoBehaviour
{
    // This procedure is run on initialisation
    void Start()
    {
        // Display topic name and question number on screen, in designated locations
        GameObject.Find("TopicName").GetComponentInChildren<Text>().text = "Topic: " + StaticVariableHolder.topic;
        GameObject.Find("QuestionNum").GetComponentInChildren<Text>().text = "Question " + StaticVariableHolder.questionNum.ToString() + "/10";
    }
}
