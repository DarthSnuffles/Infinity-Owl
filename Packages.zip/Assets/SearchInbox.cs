﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to search the message inbox
public class SearchInbox : MonoBehaviour
{
    // Store contents of input fields
    public InputField subjectSearchStr;
    public InputField senderSearchStr;

    // This procedure is run on initialisation of object
    void Start()
    {
        // Reset filters
        StaticVariableHolder.filterByGroup = null;
        StaticVariableHolder.filterByCategory = null;
        StaticVariableHolder.filterByDifficulty = null;

        // Find dropdown menu component and initialise empty list of groups
        Dropdown groupDropdown = GameObject.Find("GroupDropdown").GetComponent<Dropdown>();
        List<string> myGroups = new List<string> { "None" };

        // Query database for groups the user belongs to...
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "lmg", StaticVariableHolder.userID.ToString() };
        List<string> results = Python.RunPython(args);
        
        // Add each group to the list
        for (int i = 0; i < results.Count; i++)
        {
            string[] entry = results[i].Split(',');
            myGroups.Add(entry[1]);
        }

        // Add groups to dropdown menu, so user can select one to search by...
        groupDropdown.ClearOptions();
        groupDropdown.AddOptions(myGroups);
    }

    // Set subject search query string from input field
    public void SetSubjectSearchString(InputField text)
    {
        subjectSearchStr = text;
    }

    // Set sender search query string from input field
    public void SetSenderSearchString(InputField text)
    {
        senderSearchStr = text;
    }

    // Set group filter from dropdown menu selection
    public void SetGroupFilter()
    {
        // Find dropdown menu component
        GameObject dropdownMenu = GameObject.Find("GroupDropdown");

        // Get index of selected option
        int index = dropdownMenu.GetComponent<Dropdown>().value;

        // Get all available options in dropdown menu
        List<Dropdown.OptionData> options = dropdownMenu.GetComponent<Dropdown>().options;

        // Get string value at selected index, and set group filter
        if (options[index].text != null)
        {
            StaticVariableHolder.filterByGroup = options[index].text;
        }
    }

    // Procedure to load updated inbox, using search query strings
    public void Search()
    {
        if (subjectSearchStr != null)
        {
            StaticVariableHolder.searchByTopicSubject = subjectSearchStr.text;
        }
        if (senderSearchStr != null)
        {
            StaticVariableHolder.searchByUser = senderSearchStr.text;
        }
        if (subjectSearchStr != null || senderSearchStr != null)
        {
            // Fade into updated inbox
            Initiate.Fade("Inbox", Color.black, 4.0f);
        }
        else
        {
            // If user did not enter a subject and/or sender search string, display error message
            if (!EditorUtility.DisplayDialog("Error searching messages",
                                    "Please enter a subject search string and/or sender search string.",
                                    "OK", "Cancel"))
            {
                // If user cancels search, return to default inbox
                SceneManager.LoadScene("Inbox");
            }
        }
    }
}
#endif