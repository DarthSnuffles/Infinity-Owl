﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Class to change Unity scene
public class SwitchScene : MonoBehaviour
{ 
    // Procedure to change scene
    public void ChangeScene(string scene)
    {
        // Fade out of this scene and into the scene specified by the function's argument
        Initiate.Fade(scene, Color.black, 4.0f);
    }
}
