#!/usr/bin/python
import sys
import MySQLdb
from datetime import datetime

# Open connection to database
db = MySQLdb.connect(host="localhost",    # Host
					 user="master",       # Username
					 passwd="toclafane",  # Password
					 db="infinityowldb")    # Database Name

# Create cursor object to execute queries
cur = db.cursor()

# Function to execute SQL query and output results
def exec_print(sql):
	cur.execute(sql)
	for row in cur.fetchall():
		for i in range(0, len(row)):
			print row[i]

# Recursive function to get XP required for a particular level
def get_xp(level):
	if level == 1:
		return 0
	else:
		return get_xp(level - 1) + (level - 1) * 100	

# Function to set user's level with SQL update statement
def set_level(user, level):
	try:
		cur.execute("UPDATE Users SET Level=" + str(level) + " WHERE Username='" + user + "';")
		db.commit()
	except:
		pass

# Function to convert string difficulty to integer equivalent
def convert_difficulty(difficulty_str):
	if difficulty_str == "Easy":
		return 1
	elif difficulty_str == "Medium":
		return 2
	elif difficulty_str == "Hard":
		return 3
	elif difficulty_str == "Very Hard":
		return 4

# Function to get user's ID based on username
def get_user_id(username):
	user_id = None
	try:
		cur.execute("SELECT UserID FROM Users WHERE Username='" + str(username) + "';")
		for row in cur.fetchall():
			user_id = row[0]
	except:
		pass
	return user_id

# Function to get group's ID based on its name
def get_group_id(group_name):
	group_id = None
	try:
		cur.execute("SELECT GroupID FROM UserGroups WHERE GroupName='" + str(group_name) + "';")
		for row in cur.fetchall():
			group_id = row[0]
	except:
		pass
	return group_id

# Function to get group's name based on its ID
def get_group_name(group_id):
	group_name = None
	try:
		cur.execute("SELECT GroupName FROM UserGroups WHERE GroupID=" + str(group_id) + ";")
		for row in cur.fetchall():
			group_name = row[0]
	except:
		pass
	return group_name

# Function to get IDs of all groups the user is a member of
def my_groups(user_id):
	groups = []
	cur.execute("SELECT GroupID FROM GroupMembers WHERE UserID=" + str(user_id))
	for row in cur.fetchall():
		groups.append(row[0])
	return groups

# Function to check if user is in a given group
def in_group(user, group):
	try:
		cur.execute("SELECT * FROM GroupMembers WHERE UserID=" + str(user) + " AND GroupName='" + group + "';")
		for row in cur.fetchall():
			if row[0] == None:
				return False
			else:
				return True
	except:
		return False

# Output user's ID based on their username
if sys.argv[1] == 'uid':
	print get_user_id(sys.argv[2]);
# Output group's ID based on its name
elif sys.argv[1] == 'gid':
	print get_group_id(sys.argv[2]);
	
# Register new user, and output their ID
elif sys.argv[1] == "r":
	username_taken = False
	cur.execute("SELECT UserID FROM Users WHERE Username='" + sys.argv[2] + "';")
	for row in cur.fetchall():
		username_taken = True
	if not username_taken:
		cur.execute("INSERT INTO Users VALUES (NULL, '" + sys.argv[2] + "', '" + sys.argv[3] + "', '" + sys.argv[4] + "', '" + sys.argv[5] + "', '" + sys.argv[6] + "', 1, 0);")
		db.commit()		
		exec_print("SELECT UserID FROM Users WHERE Username='" + sys.argv[2] + "';")
	else:
		print "Error"
# Get username and password
elif sys.argv[1] == "u":
	exec_print("SELECT UserID, FirstName, Surname FROM Users WHERE Username='" + sys.argv[2]
				+ "' AND Password='" + sys.argv[3] + "';")
elif sys.argv[1] == "mp":
	exec_print("SELECT Level, XP FROM Users WHERE UserID=" + sys.argv[2] + ";")
elif sys.argv[1] == "cc":
	cur.execute("UPDATE Users SET OwlColour='" + sys.argv[3] + "' WHERE UserID=" + sys.argv[2] + ";")
	db.commit()
# Get topics to fill main menu
elif sys.argv[1] == "f":
	exec_print("SELECT TopicName FROM Topics WHERE Category='" + sys.argv[2] + "';")
# Get topic ID from name
elif sys.argv[1] == "ti":
	exec_print("SELECT TopicID, Approved FROM Topics WHERE TopicName='" + sys.argv[2] + "';")
# Get topic name from ID
elif sys.argv[1] == "tn":
	exec_print("SELECT TopicName, Approved FROM Topics WHERE TopicID=" + sys.argv[2] + ";")
elif sys.argv[1] == "ctn":
	exec_print("SELECT TopicName, Approved FROM CustomTopics WHERE TopicID=" + sys.argv[2] + ";")
# Get quiz question
elif sys.argv[1] == 'q':
	exec_print("SELECT Question, Answer1, Answer2, Answer3, CorrectAnswer, ImagePath " +
	"FROM Questions WHERE TopicID=" + sys.argv[2] + " AND QuestionNum=" + sys.argv[3] + ";")
elif sys.argv[1] == 'cq':
	exec_print("SELECT Question, Answer1, Answer2, Answer3, CorrectAnswer, ImagePath " +
	"FROM CustomQuestions WHERE TopicID=" + sys.argv[2] + " AND QuestionNum=" + sys.argv[3] + ";")
elif sys.argv[1] == 'ie':
	exec_print("SELECT ImaginativeExercise FROM Topics WHERE TopicID=" + sys.argv[2] + ";")
elif sys.argv[1] == 'ir':
	response = (sys.argv[4]).replace("'", "''")
	print response
	submissions = 0
	try:
		cur.execute("SELECT MAX(SubmissionNumber) FROM ImaginativeResponses WHERE UserID=" + sys.argv[2] + " AND TopicID=" + sys.argv[3] + ";")
		for row in cur.fetchall():
			submissions = row[0]
		if submissions == None:
			submissions = 1
		else:
			submissions = int(submissions) + 1
	except:
		submissions = 1			
	cur.execute("INSERT INTO ImaginativeResponses VALUES (" + sys.argv[2] + ", " + sys.argv[3] + ", " + str(submissions) + ", '" + response + "', '" + str(datetime.now()) + "');")
	db.commit()
	
# Check if user has earnt completion XP bonus
elif sys.argv[1] == 'b':
	category = None
	cur.execute("SELECT Category FROM Topics WHERE TopicID = " + sys.argv[3] + ";")
	for row in cur.fetchall():
		category = row[0]
	sql = "SELECT DISTINCT Topics.TopicID, Topics.Category FROM Topics INNER JOIN Scores ON Topics.TopicID = Scores.TopicID WHERE Scores.UserID=" + sys.argv[2]
	if sys.argv[4] == "fs":
		sql += " AND Scores.Score = 10;"
	elif sys.argv[4] == "c":
		sql += ";"
	cur.execute(sql)
	topics = []
	for row in cur.fetchall():
		topics.append([row[0], row[1]])
	bonus = 0
	if len(topics) == 90:
		if sys.argv[4] == "c":
			bonus += 200
		elif sys.argv[4] == "fs":
			bonus += 2000
	count = 0
	for topic in topics:
		if topic[1] == category:
			count += 1
	if count == 15:
		if sys.argv[4] == "c":
			bonus += 100
		elif sys.argv[4] == "fs":
			bonus += 1000
	print bonus
# Add XP to user
elif sys.argv[1] == '+xp':
	cur.execute("SELECT XP, Level FROM Users WHERE Username='" + sys.argv[2] + "';")
	for row in cur.fetchall():
		xp = row[0]
		level = row[1]
	xp += int(sys.argv[3])
	cur.execute("UPDATE Users SET XP=" + str(xp) + " WHERE Username='" + sys.argv[2] + "';")
	db.commit()
	lvl = level
	levelled = False
	level_up = False
	while not levelled:
		next_level_xp = get_xp(lvl + 1)
		if xp >= next_level_xp:
			level_up = True
			set_level(sys.argv[2], lvl + 1)
			
		else:
			levelled = True
		lvl += 1
	print level_up
	print (lvl - 1)
			
elif sys.argv[1] == 'gxp':
	print get_xp(int(sys.argv[2]))
# Insert quiz attempt number and score
elif sys.argv[1] == 's':
	prev_best = 0
	try:
		cur.execute("SELECT MAX(Score) FROM Scores WHERE UserID=" + sys.argv[2] + " AND TopicID=" + sys.argv[3] + ";")
		for row in cur.fetchall():
			prev_best = row[0]
	except:
		pass
	print prev_best
	
	attempts = 0
	try:
		cur.execute("SELECT MAX(AttemptNumber) FROM Scores WHERE UserID=" + sys.argv[2] + " AND TopicID=" + sys.argv[3] + ";")
		for row in cur.fetchall():
			attempts = row[0]
		if attempts == None:
			attempts = 1
		else:
			attempts = int(attempts) + 1
	except:
		attempts = 1
	cur.execute("INSERT INTO Scores VALUES (" + sys.argv[2] + ", " + sys.argv[3] + ", " + str(attempts) + ", " + sys.argv[4] +", '" + str(datetime.now()) + "');")
	db.commit()
# Check if topic for new custom quiz exists, and if not get topic ID
elif sys.argv[1] == 'cti':
		topic_exists = False
		try:
			cur.execute("SELECT TopicID FROM CustomTopics WHERE TopicName='" + sys.argv[2] + "';")
			for row in cur.fetchall():
				topic_exists = True
		except:
			pass
		if not topic_exists:
			topic_exists = False
			try:
				cur.execute("SELECT MAX(TopicID) FROM CustomTopics;")
				for row in cur.fetchall():
					topic_id = row[0] + 1
				print topic_id
			except:
				topic_id = 1
				print topic_id
		else:
			print "Exists"
# Insert quiz topic for custom quiz
elif sys.argv[1] == 'iqt':
		try:
			cur.execute("INSERT INTO CustomTopics VALUES (" + sys.argv[2] + ", '" + sys.argv[3] + "', " + sys.argv[4] + ", '" + str(datetime.now()) + "', 0);")
			db.commit()
		except Exception as e:
			print "Error inserting topic..."
			print str(e)
			raw_input()
# Insert quiz question for custom quiz
elif sys.argv[1] == 'iqq':
		cur.execute("INSERT INTO CustomQuestions VALUES (" + sys.argv[2] + ", " + sys.argv[3] + ", '" + sys.argv[4] + "', '" + sys.argv[5] + "', '" + sys.argv[6] +"', '" + sys.argv[7] + "', '" + sys.argv[8] + "', '" + sys.argv[9] + "');")
		db.commit()
# Create group
elif sys.argv[1] == 'cg':
	group_name = (sys.argv[2]).replace("'", "''")
	try:
		group_already_exists = False
		cur.execute("SELECT GroupID FROM UserGroups WHERE GroupName='" + group_name + "';")
		for row in cur.fetchall():
			group_already_exists = True
		if not group_already_exists:
			cur.execute("INSERT INTO UserGroups VALUES (NULL, '" + group_name + "', '" + sys.argv[3] + "', " + sys.argv[4] + ", NULL, NULL);")
			db.commit()		
			cur.execute("SELECT GroupID FROM UserGroups WHERE GroupName='" + group_name + "';")
			for row in cur.fetchall():
				group_id = row[0]
			cur.execute("INSERT INTO GroupMembers VALUES (" + sys.argv[4] + ", " + str(group_id) + ");")
			db.commit()	
			print "Success"
		else:
			print "Error"
	except:
		print "Error"
# Join group		
elif sys.argv[1] == 'jg':
	group_name = (sys.argv[2]).replace("'", "''")
	try:
		cur.execute("SELECT GroupID FROM UserGroups WHERE GroupName='" + group_name + "' AND Password='" + sys.argv[3] + "';")
		for row in cur.fetchall():
			group_id = row[0]
		cur.execute("INSERT INTO GroupMembers VALUES (" + sys.argv[4] + ", " + str(group_id) + ");")
		db.commit()		
		print "Success"
	except:
		print "Error"	
# Get overall leaderboard entries
elif sys.argv[1] == 'l':
	cur.execute("SELECT Username, XP, Level FROM Users ORDER BY XP DESC;")
	n = 0
	for row in cur.fetchall():
		n += 1
		entry = str(n) + "," + row[0] + "," + str(row[1]) + "," + str(row[2])
		print entry	
# Show overall leaderboard entries, filtered by group
elif sys.argv[1] == 'lg':
	try:
		cur.execute("SELECT Username, XP, Level FROM (Users INNER JOIN GroupMembers ON Users.UserID = GroupMembers.UserID) INNER JOIN UserGroups ON GroupMembers.GroupID = UserGroups.GroupID WHERE UserGroups.GroupName='" + sys.argv[2] + "' ORDER BY XP DESC;")
	except:
		cur.execute("SELECT Username, XP, Level FROM Users ORDER BY XP DESC;")
	n = 0
	for row in cur.fetchall():
		n += 1
		entry = str(n) + "," + row[0] + "," + str(row[1]) + "," + str(row[2])
		print entry	
# List recent scores, using filters
elif sys.argv[1] == 'ls':
	queryStr = "SELECT Username, TopicName, Score FROM ((Scores INNER JOIN Topics ON Scores.TopicID = Topics.TopicID) INNER JOIN Users ON Scores.UserID = Users.UserID)"
	if sys.argv[2] != "None":
		queryStr += " INNER JOIN GroupMembers ON Users.UserID = GroupMembers.UserID "
		cur.execute("SELECT GroupID FROM UserGroups WHERE GroupName='" + sys.argv[2] + "';")
		for row in cur.fetchall():
			group_id = row[0]
		queryStr += " WHERE GroupMembers.GroupID=" + str(group_id)
		if sys.argv[3] != "None":
			queryStr += " AND Topics.Category='" + str(sys.argv[3]) + "'"
			if sys.argv[4] != "None":
				difficulty = convert_difficulty(sys.argv[4])
				queryStr += " AND Topics.Difficulty=" + str(difficulty)
		else:
			if sys.argv[4] != "None":
				difficulty = convert_difficulty(sys.argv[4])
				queryStr += " AND Topics.Difficulty=" + str(difficulty)
	else:
		if sys.argv[3] != "None":
			queryStr += " WHERE Topics.Category='" + str(sys.argv[3]) + "'"
			if sys.argv[4] != "None":
				difficulty = convert_difficulty(sys.argv[4])
				queryStr += " AND Topics.Difficulty=" + str(difficulty)
		else:
			if sys.argv[4] != "None":
				difficulty = convert_difficulty(sys.argv[4])
				queryStr += " WHERE Topics.Difficulty=" + str(difficulty)
	queryStr += " ORDER BY Scores.DateTime DESC;"
	cur.execute(queryStr)
	
	users_and_topics = []
	n = 0
	for row in cur.fetchall():
		n += 1
		user_and_topic = [row[0], row[1]]
		if user_and_topic not in users_and_topics:
			users_and_topics.append(user_and_topic)
			entry = str(row[0]) + "," + str(row[1]) + "," + str(row[2])
			print entry	
# List my groups
elif sys.argv[1] == 'lmg':
	sql = "SELECT GroupMembers.GroupID, GroupName FROM GroupMembers INNER JOIN UserGroups ON GroupMembers.GroupID = UserGroups.GroupID WHERE UserID = " + sys.argv[2] + " ORDER BY GroupID ASC;"
	cur.execute(sql)
	my_groups = []
	for row in cur.fetchall():
		my_groups.append([row[0], row[1]])
		
	rank = None
	for n in range(0, len(my_groups)):
		group_members = []
		cur.execute("SELECT GroupMembers.UserID, XP FROM GroupMembers INNER JOIN Users ON GroupMembers.UserID = Users.UserID WHERE GroupID = " + str(my_groups[n][0]) + " ORDER BY XP DESC;")
		m = 0
		for row in cur.fetchall():
			m += 1
			group_members.append([row[0], row[1]])
			if str(row[0]) == sys.argv[2]:
				rank = m
		
		entry = str(my_groups[n][0]) + "," + my_groups[n][1] + "," + str(len(group_members)) + "," + str(rank)
		print entry
# Check group permissions		
elif sys.argv[1] == 'cgp':
	admin = False
	cur.execute("SELECT AdminID FROM UserGroups WHERE GroupName='" + sys.argv[2] + "';")
	for row in cur.fetchall():
		if int(row[0]) == int(sys.argv[3]):
			admin = True
	print admin
# Unlock quiz for group
elif sys.argv[1] == 'uq':
	group_name = (sys.argv[2]).replace("'", "''")
	deadlineParts = sys.argv[4].split("/")
	deadline = deadlineParts[2] + "-" + deadlineParts[1] + "-" + deadlineParts[0]
	cur.execute("UPDATE UserGroups SET TopicUnlock='" + sys.argv[3] + "', Deadline='" + deadline + "' WHERE GroupName='" + group_name + "';")
	db.commit()	
# Get group unlock
elif sys.argv[1] == 'gu':
	group_name = (sys.argv[2]).replace("'", "''")
	exec_print("SELECT TopicUnlock FROM UserGroups WHERE GroupName='" + group_name + "';")
# Check deadline for group unlock, and reset if it has been passed
elif sys.argv[1] == 'cu':
	group_name = (sys.argv[2]).replace("'", "''")
	deadline = None
	cur.execute("SELECT Deadline FROM UserGroups WHERE GroupName='" + group_name + "';")
	for row in cur.fetchall():
		deadline = row[0]
	if deadline < datetime.now():
		cur.execute("UPDATE UserGroups SET TopicUnlock=NULL, Deadline=NULL WHERE GroupName='" + group_name + "';")
		db.commit()	
# List custom quizzes
elif sys.argv[1] == 'lcq':
	queryStr = "SELECT DISTINCT CustomTopics.TopicID, CustomTopics.TopicName, Username FROM (CustomTopics INNER JOIN Users ON CustomTopics.UploaderID = Users.UserID) INNER JOIN GroupMembers ON Users.UserID = GroupMembers.UserID"
	if sys.argv[2] != "None":
		cur.execute("SELECT GroupID FROM UserGroups WHERE GroupName='" + sys.argv[2] + "';")
		for row in cur.fetchall():
			group_id = row[0]
		queryStr += " WHERE GroupMembers.GroupID=" + str(group_id)
		if sys.argv[3] != "None":
			queryStr += " AND CustomTopics.TopicName LIKE '%" + str(sys.argv[3]) + "%'"
			if sys.argv[4] != "None":
				queryStr += " AND Users.Username LIKE '%" + str(sys.argv[4]) + "%'"
		else:
			if sys.argv[4] != "None":
				queryStr += " AND Users.Username LIKE '%" + str(sys.argv[4]) + "%'"
	else:
		if sys.argv[3] != "None":
			queryStr += " WHERE CustomTopics.TopicName LIKE '%" + str(sys.argv[3]) + "%'"
			if sys.argv[4] != "None":
				queryStr += " AND Users.Username LIKE '%" + str(sys.argv[4]) + "%'"
		else:
			if sys.argv[4] != "None":
				queryStr += " WHERE Users.Username LIKE '%" + str(sys.argv[4]) + "%'"
	queryStr += " ORDER BY CustomTopics.UploadDateTime DESC;"
	cur.execute(queryStr)
	
	for row in cur.fetchall():	
		entry = str(row[0]) + "," + str(row[1]) + "," + str(row[2])
		print entry
# Send message
elif sys.argv[1] == 'sm':
	message_subject = (sys.argv[4]).replace("'", "''")
	message_text = (sys.argv[5]).replace("'", "''")
	cur.execute("INSERT INTO Messages VALUES (NULL, " + sys.argv[2] + ", '" + sys.argv[3] + "', '" + message_subject + "', '" + message_text + "', '" + str(datetime.now()) + "');")
	db.commit()
# View message inbox
elif sys.argv[1] == 'vi':
	inbox = []
	groups = my_groups(sys.argv[2])
	cur.execute("SELECT MessageID, SenderID, Receivers, MessageSubject FROM Messages ORDER BY SendDateTime DESC")
	for row in cur.fetchall():
		receivers = row[2]
		receiversSplit = receivers.split(':')
		receiverGroups = receiversSplit[0].split(",")
		receiverUsers = receiversSplit[1].split(",")
		if sys.argv[2] in receiverUsers:
			if sys.argv[3] == "None":
				inbox.append([row[0], row[1], row[3].replace("''", "'")])
			else:
				if in_group(row[1], sys.argv[3]):
					inbox.append([row[0], row[1], row[3].replace("''", "'")])
		else:
			for group in groups:
				if group in receiverGroups:
					if sys.argv[3] == "None":
						inbox.append([row[0], row[1], row[3].replace("''", "'")])
					else:
						group_name = get_group_name(group)
						if group_name == sys.argv[3]:
							inbox.append([row[0], row[1], row[3].replace("''", "'")])
	for message in inbox:
		username = None
		cur.execute("SELECT Username FROM Users WHERE UserID=" + str(message[1]) + ";")
		for row in cur.fetchall():
			username = row[0]
		if sys.argv[4] == "None":
			if sys.argv[5] == "None":
				print str(message[0]) + "," + username + "," + str(message[2])
			else:
				if sys.argv[5] in username:
					print str(message[0]) + "," + username + "," + str(message[2])
		else:
			if sys.argv[4] in str(message[2]):
				if sys.argv[5] == "None":
					print str(message[0]) + "," + username + "," + str(message[2])
				else:
					if sys.argv[5] in username:
						print str(message[0]) + "," + username + "," + str(message[2])
# View received message
elif sys.argv[1] == 'vm':
	cur.execute("SELECT Users.Username, Messages.MessageSubject, Messages.MessageText FROM Messages INNER JOIN Users ON Messages.SenderID = Users.UserID WHERE MessageID=" + str(sys.argv[2]) + ";")
	for row in cur.fetchall():
		print row[0]
		print row[1].replace("''", "'")
		print row[2].replace("''", "'")
		
# Close connection to database
db.close()