﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to load received message
public class LoadMessage : MonoBehaviour
{
    // This procedure is run on initialisation
    void Start()
    {
        // Initialise empty list for query results
        List<string> results = null;

        if (StaticVariableHolder.messageID != 0)
        {
            // If a message ID was entered, query database for message with that ID
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "vm", StaticVariableHolder.messageID.ToString() };
            results = Python.RunPython(args);
        }

        // Display message, including the sender, subject and content
        string header = "Message from:\n" + results[0];
        GameObject.Find("MessageTitle").GetComponentInChildren<Text>().text = header;
        GameObject.Find("MessageSubject").GetComponentInChildren<Text>().text = results[1];
        GameObject.Find("MessageContent").GetComponentInChildren<Text>().text = results[2];
    }
}
