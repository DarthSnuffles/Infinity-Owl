﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to load list of groups (that the user belongs to)
public class LoadMyGroups : MonoBehaviour
{
    // This procedure is run on initialisation
    void Start()
    {
        // Reset variable for whether group options are being viewed for a group
        StaticVariableHolder.groupOptions = null;

        // Query database for groups the user belongs to
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "lmg", StaticVariableHolder.userID.ToString() };
        List<string> results = Python.RunPython(args);

        // Find group dropdown component, and initialise empty list
        Dropdown groupDropdown = GameObject.Find("GroupDropdown").GetComponent<Dropdown>();
        List<string> myGroups = new List<string> { "None" };

        // Iterate through results
        for (int i = 0; i < results.Count; i++)
        {
            // Split entry for group at commas
            string[] entry = results[i].Split(',');
            // Display group ID, group name, number of members, and user's position in group
            GameObject.Find("GroupIDList").GetComponent<Text>().text += "\n" + entry[0];
            GameObject.Find("GroupNameList").GetComponent<Text>().text += "\n" + entry[1];
            GameObject.Find("MembersList").GetComponent<Text>().text += "\n" + entry[2];
            GameObject.Find("MyRankList").GetComponent<Text>().text += "\n" + entry[3];
            // Add group to list of groups the user belongs to
            myGroups.Add(entry[1]);
        }

        // Add groups to dropdown menu
        groupDropdown.ClearOptions();
        groupDropdown.AddOptions(myGroups);
    }

    // Procedure to view admin options for a group
    public void ViewAdminOptions()
    {
        // Find dropdown menu component
        GameObject dropdownMenu = GameObject.Find("GroupDropdown");

        // Get index of selected option
        int index = dropdownMenu.GetComponent<Dropdown>().value;

        // Get all available options in dropdown menu
        List<Dropdown.OptionData> options = dropdownMenu.GetComponent<Dropdown>().options;

        // Get string value at selected index
        if (options[index].text != "None")
        {
            // If user selected a group, query database to check permissions for user (they must be an admin to proceed)
            string group = options[index].text;
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "cgp", "\"" + group + "\"", StaticVariableHolder.userID.ToString() };
            List<string> results = Python.RunPython(args);

            if (results[0] == "True")
            {
                // If user is admin of selected group, load admin options screen
                StaticVariableHolder.groupOptions = group;
                SceneManager.LoadScene("AdminOptions");
            } else 
            {
                // Otherwise, they do not have permission so display error message
                if (!EditorUtility.DisplayDialog("Error",
               "You are not the admin of that group, so are not permitted to access this feature.",
               "OK", "Create New Group"))
                {
                    // If user chooses to create a new group, transfer them to relevant screen
                    SceneManager.LoadScene("CreateGroup");
                }
            }
        } else
        {
            //If no group was selected, display error message
            if (!EditorUtility.DisplayDialog("Error",
            "Please select a group.",
            "OK", "Create New Group"))
            {
                // If user chooses to create a new group, transfer them to relevant screen
                SceneManager.LoadScene("CreateGroup");
            }
        }
    }
}
#endif