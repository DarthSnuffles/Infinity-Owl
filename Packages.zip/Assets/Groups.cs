﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to create and join groups of users
public class Groups : MonoBehaviour
{ 
    // Store contents of input fields
    public InputField groupName;
    public InputField password;

    // Set group name from input field
    public void SetGroupName(InputField text)
    {
        groupName = text;
    }

    // Set group's password from input field
    public void SetPassword(InputField text)
    {
        password = text;
    }

    // Procedure to create a group with the entered name and password
    public void CreateGroup()
    {
        try
        {
            // Insert record for new group into database
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "cg", "\"" + groupName.text + "\"", "\"" + password.text + "\"", StaticVariableHolder.userID.ToString() };
            List<string> results = Python.RunPython(args);

            if (results[0] != "Error")
            {
                // If the group was successfully created, return to Groups menu
                SceneManager.LoadScene("Groups");
            } else
            {
                // If group name is already taken, display error message
                if (!EditorUtility.DisplayDialog("Error creating group",
               "That group name is already taken.\nPlease try another one.",
               "OK", "Cancel"))
                {
                    // If the user cancels, return to Groups menu
                    SceneManager.LoadScene("Groups");
                }
            }
            
        } catch
        {
            // If user entered an invalid input for group name or password, display error message
            if (!EditorUtility.DisplayDialog("Error creating group",
                "Invalid input. Please try again.",
                "OK", "Cancel"))
            {
                // If the user cancels. return to Groups menu
                SceneManager.LoadScene("Groups");
            }
        }
    }

    // Procedure to join a group with the entered name and password
    public void JoinGroup()
    {
        try
        {
            // Insert record into database, asserting that user belongs to the entered group, as long as they entered the correct password and are not already a member
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "jg", "\"" + groupName.text + "\"", "\"" + password.text + "\"", StaticVariableHolder.userID.ToString() };
            List<string> results = Python.RunPython(args);

            if (results[0] != "Error")
            {
                // If the user successfully joined the group, return to Groups menu
                SceneManager.LoadScene("Groups");
            } else
            {
                // Otherwise, the user must have entered an incorrect group name or password, or they are already a member of the group, so display error message
                if (!EditorUtility.DisplayDialog("Error joining group",
               "Incorrect group name or password (or you are already a member). Please try again.",
               "OK", "Cancel"))
                {
                    // If the user cancels, return to Groups menu
                    SceneManager.LoadScene("Groups");
                }
            }

        }
        catch
        {
            // If user entered an invalid input for group name or password, display error message
            if (!EditorUtility.DisplayDialog("Error joining group",
               "Invalid input. Please try again.",
               "OK", "Cancel"))
            {
                // If the user cancels, return to Groups menu
                SceneManager.LoadScene("Groups");
            }
        }
    }
}
#endif
