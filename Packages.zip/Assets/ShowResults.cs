﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to display quiz results
public class ShowResults : MonoBehaviour
{
    // This procedure is run on initialisation of object
	void Start()
	{
        int xpBonus = 0;
        List<string> results;
        // If the user played a sample quiz, not a custom quiz...
        if (StaticVariableHolder.custom == false)
        {
            // Update database with user's score
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "s", StaticVariableHolder.userID.ToString(), StaticVariableHolder.topicID.ToString(), StaticVariableHolder.score.ToString() };
            results = Python.RunPython(args);

            int prevBest = 0;
            try
            {
                // Get user's previous best score from output of Python script
                prevBest = Int32.Parse(results[0]);
            } 
            catch
            {
                // If user has not played this quiz before...
                if (results[0] == "None")
                {
                    // Query database to check if user has earned XP bonus for completing this quiz
                    string[] args2 = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "b", StaticVariableHolder.userID.ToString(), StaticVariableHolder.topicID.ToString(), "c" };
                    results = Python.RunPython(args2);
                    xpBonus += Int32.Parse(results[0]);
                }
            }

            // Calculate user's improvement on their previous best score (may be negative)
            int improvement = StaticVariableHolder.score - prevBest;

            // If they have improved, add XP for each additional correct answer
            if (improvement > 0)
            {
                xpBonus += improvement * 10;
            }

            // If previous best score was less than 10, and user has now obtained perfect score on quiz...
            if (prevBest < 10 && StaticVariableHolder.score == 10)
            {
                // Query database to check if user has earned XP bonus for obtaining perfect score on this quiz
                string[] args2 = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "b", StaticVariableHolder.userID.ToString(), StaticVariableHolder.topicID.ToString(), "fs" };
                results = Python.RunPython(args2);
                xpBonus += (100 + Int32.Parse(results[0]));
            }
        }

        // Initialise results message to show user's score
        string message = "Well done! You scored " + StaticVariableHolder.score.ToString() + "/10";

        // Reward user with XP, based on their performance
        string[] args3 = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "+xp", StaticVariableHolder.username, (10 + xpBonus).ToString() };
        results = Python.RunPython(args3);

        // If the user has levelled up, output message
        if (results[0] == "True")
        {
            message += "\nLEVEL UP! You are now level " + results[1];
        }

        // Display topic name and results message
        GameObject.Find("TopicName").GetComponentInChildren<Text>().text = "Topic: " + StaticVariableHolder.topic;
        GameObject.Find("Results").GetComponentInChildren<Text>().text = (message);

        // Load owl image
        WWW www = new WWW("file://C://Users//darth//Pictures//ProjectImages//OwlCartoon1.png");
        GameObject image = GameObject.Find("RawImage");
        image.GetComponent<RawImage>().texture = www.texture;

        // Reset static variable for user's quiz score
        StaticVariableHolder.score = 0;
    }
}
