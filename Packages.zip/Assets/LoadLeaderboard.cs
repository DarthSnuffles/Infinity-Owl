﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// Class to load leaderboard of recent quiz scores
public class LoadLeaderboard : MonoBehaviour
{
    // This procedure is run on initialisation
    void Start()
    {
        // Initialise filters
        string groupFilter = "None";
        string categoryFilter = "None";
        string difficultyFilter = "None";

        if (StaticVariableHolder.filterByGroup != null)
        {
            // If group filter was set, turn it on
            groupFilter = StaticVariableHolder.filterByGroup;
        }
        if (StaticVariableHolder.filterByCategory != null)
        {
            // If category filter was set, turn it on
            categoryFilter = StaticVariableHolder.filterByCategory;
        }
        if (StaticVariableHolder.filterByDifficulty != null)
        {
            // If difficulty filter was set, turn it on
            difficultyFilter = StaticVariableHolder.filterByDifficulty;
        }

        // Query database for quiz scores using filters
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "ls",  "\"" + groupFilter + "\"", "\"" + categoryFilter + "\"", difficultyFilter };
        List<string> results = Python.RunPython(args);

        // Iterate through results
        for (int i = 0; i < results.Count; i++) {
            // Split entry for quiz score at commas
            string[] entry = results[i].Split(',');
            // Display users, quiz topics and scores (sorted from most to least recent)
            GameObject.Find("UserLeaderboard").GetComponent<Text>().text += "\n" + entry[0];
            GameObject.Find("TopicLeaderboard").GetComponent<Text>().text += "\n" + entry[1];
            GameObject.Find("ScoreLeaderboard").GetComponent<Text>().text += "\n" + entry[2];
        }
    }

    // Procedure to return to overall leaderboard of users
    public void ReturnToOverallLeaderboard()
    {
        // Clear group filter and load overall leaderboard
        StaticVariableHolder.filterByGroup = null;
        Initiate.Fade("OverallLeaderboard", Color.black, 4.0f);
    }
}
