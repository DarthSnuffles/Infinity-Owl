﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to create a custom quiz and upload it to the community
public class CreateQuiz : MonoBehaviour
{
    // Store contents of input fields for each question
    public InputField question;
    public InputField imageURL;
    public InputField answer1;
    public InputField answer2;
    public InputField answer3;
    // Store index of correct answer out of possible answers, for each question
    public int correctAnswerNum;

    // Set custom topic name from input field
    public void SetTopic(InputField topicName)
    {
        // Assign custom topic name to static variable, so all custom quiz questions are then associated with this topic
        StaticVariableHolder.topic = topicName.text;
    }

    // Set question text from input field
    public void SetQuestion(InputField text)
    {
        question = text;
    }

    // Set image URL for question from input field
    public void SetImageURL(InputField text)
    {
        imageURL = text;
    }

    // Set first possible answer from input field
    public void SetAnswer1(InputField text)
    {
        answer1 = text;
    }

    // Set second possible answer from input field
    public void SetAnswer2(InputField text)
    {
        answer2 = text;
    }

    // Set third possible answer from input field
    public void SetAnswer3(InputField text)
    {
        answer3 = text;
    }

    // Set correct answer from tickbox (one of the possible answers must be ticked)
    public void SetCorrectAnswer(int answerNum)
    {
        correctAnswerNum = answerNum;
    }

    // Procedure to start the quiz creation process
    public void StartCreation()
    {
        if (StaticVariableHolder.topic != null)
        {
            // If a topic name was entered, check if a custom topic already exists with that name
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "cti", "\"" + StaticVariableHolder.topic };
            List<string> results = Python.RunPython(args);

            if (results[0] != "Exists")
            {
                // If the topic name has not been taken, set topic ID and question number to be created (start with question 1)
                StaticVariableHolder.topicID = Int32.Parse(results[0]);
                StaticVariableHolder.questionNum = 1;

                // Initialise variables for question content
                question = null;
                imageURL = null;
                answer1 = null;
                answer2 = null;
                answer3 = null;
                correctAnswerNum = -1;

                // Fade into dialogue to add first quiz question
                Initiate.Fade("CreateQuiz", Color.black, 2.0f);
            } else
            {
                // If the topic name is taken, display error message
                if (!EditorUtility.DisplayDialog("Error starting quiz creation",
                    "A custom quiz under that topic name already exists. Please try another one.",
                    "OK", "Cancel"))
                {
                    // If the user cancels, return to Main Menu
                    SceneManager.LoadScene("MainMenu");
                }
            }
        } else
        {
            // If user did not enter a name for the custom topic, display error message
            if (!EditorUtility.DisplayDialog("Error starting quiz creation",
               "Please enter a topic name.",
               "OK", "Cancel"))
            {
                // If the user cancels, return to Main Menu
                SceneManager.LoadScene("MainMenu");
            }
        }     
	}

    // Procedure to add entered quiz question details, and go on to the next one (or the end of the quiz creation process)
    public void NextQuestion()
    {
        if (imageURL == null) imageURL.text = "";   // If user did not enter an image URL, set variable to empty string

        if (question != null && answer1 != null && answer2 != null && answer3 != null && correctAnswerNum != -1)
        {
            // If user entered a question and 3 possible answers, and selected one correct answer, allow them to proceed
            // Set correct answer text from ticked input field
            string correctAnswer = null;
            if (correctAnswerNum == 1)
            {
                correctAnswer = answer1.text;
            } else if (correctAnswerNum == 2)
            {
                correctAnswer = answer2.text;
            } else if (correctAnswerNum == 3)
            {
                correctAnswer = answer3.text;
            }

            // Assign question details to appropriate indices of static 'quiz' array of arrays
            int n = StaticVariableHolder.questionNum;
            StaticVariableHolder.quiz[n-1] = new string[6];
            StaticVariableHolder.quiz[n-1][0] = question.text;
            StaticVariableHolder.quiz[n-1][1] = imageURL.text;
            StaticVariableHolder.quiz[n-1][2] = answer1.text;
            StaticVariableHolder.quiz[n-1][3] = answer2.text;
            StaticVariableHolder.quiz[n-1][4] = answer3.text;
            StaticVariableHolder.quiz[n-1][5] = correctAnswer;

            if (StaticVariableHolder.questionNum == 10)
            {
                // If user has entered all 10 questions, proceed to confirmation of submission
                Initiate.Fade("SubmitQuiz", Color.black, 2.0f);
            }
            else
            {
                // Otherwise, reset question variables
                question = null;
                imageURL = null;
                answer1 = null;
                answer2 = null;
                answer3 = null;
                correctAnswerNum = -1;

                // Increment question number, and load dialogue to add the next quiz question
                StaticVariableHolder.questionNum += 1;
                SceneManager.LoadScene("CreateQuiz");
            }
        } else
        {
            // If user did not enter all the required information for a question, display error message
            if (!EditorUtility.DisplayDialog("Error adding question",
               "Please enter a question and three possible answers, ticking the correct one.",
               "OK", "Cancel"))
            {
                // If the user cancels, return to main menu
                SceneManager.LoadScene("MainMenu");
            }
        }     
    }

    // Procedure to return to previous quiz question, to edit its content
    public void PreviousQuestion()
    {
        if (StaticVariableHolder.questionNum > 1)
        { 
            // If this is not the first question of the custom quiz, reset question variables
            question = null;
            imageURL = null;
            answer1 = null;
            answer2 = null;
            answer3 = null;
            correctAnswerNum = -1;

            // Decrement question number, and load dialogue to enter the previous quiz question again
            StaticVariableHolder.questionNum -= 1;
            SceneManager.LoadScene("CreateQuiz");
        } else
        {
            // If the user clicks 'Back' on the first question, return to main menu
            SceneManager.LoadScene("MainMenu");
        }
    }

    // Procedure to submit the custom quiz details to the community server
    public void SubmitQuiz()
    {
        // Insert record for new custom topic into the database
        string[] topic_args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "iqt", StaticVariableHolder.topicID.ToString(), "\"" + StaticVariableHolder.topic + "\"", StaticVariableHolder.userID.ToString() };
        Python.RunPython(topic_args);

        // Iterate through entered quiz question details, stored in static array of arrays
        for (int n = 0; n < StaticVariableHolder.quiz.Length; n++)
        {
            // Set question variables from appropriate indices of array of arrays
            string question = StaticVariableHolder.quiz[n][0];
            string imageURL = StaticVariableHolder.quiz[n][1];
            string answer1 = StaticVariableHolder.quiz[n][2];
            string answer2 = StaticVariableHolder.quiz[n][3];
            string answer3 = StaticVariableHolder.quiz[n][4];
            string correctAnswer = StaticVariableHolder.quiz[n][5];

            // Insert record for new custom quiz question into the database, including the question, image URL, 3 possible answers, and correct answer...
            string[] question_args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "iqq", StaticVariableHolder.topicID.ToString(), (n+1).ToString(), "\"" + question + "\"", "\"" + answer1 + "\"", "\"" + answer2 + "\"", "\"" + answer3 + "\"", "\"" + correctAnswer + "\"", "\"" + imageURL + "\"" };
            List<string> results = Python.RunPython(question_args);
        }
        // Return to main menu, now that custom quiz has successfully been created!
        SceneManager.LoadScene("MainMenu");
    }
}
#endif