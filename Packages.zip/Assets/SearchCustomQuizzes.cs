﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to search the custom quizzes
public class SearchCustomQuizzes : MonoBehaviour
{
    // Store contents of input fields
    public InputField topicSearchStr;
    public InputField uploaderSearchStr;

    // This procedure is run on initialisation of object
    void Start()
    {
        // Reset filters
        StaticVariableHolder.filterByGroup = null;
        StaticVariableHolder.filterByCategory = null;
        StaticVariableHolder.filterByDifficulty = null;

        // Find dropdown menu component and initialise empty list of groups
        Dropdown groupDropdown = GameObject.Find("GroupDropdown").GetComponent<Dropdown>();
        List<string> myGroups = new List<string> { "None" };

        // Query database for groups the user belongs to...
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "lmg", StaticVariableHolder.userID.ToString() };
        List<string> results = Python.RunPython(args);

        // Add each group to the list
        for (int i = 0; i < results.Count; i++)
        {
            string[] entry = results[i].Split(',');
            myGroups.Add(entry[1]);
        }

        // Add groups to dropdown menu, so user can select one to search by...
        groupDropdown.ClearOptions();
        groupDropdown.AddOptions(myGroups);
    }

    // Set topic search query string from input field
    public void SetTopicSearchString(InputField text)
    {
        topicSearchStr = text;
    }

    // Set uploader search query string from input field
    public void SetUploaderSearchString(InputField text)
    {
        uploaderSearchStr = text;
    }

    // Set group filter from dropdown menu selection
    public void SetGroupFilter()
    {
        // Find dropdown menu component
        GameObject dropdownMenu = GameObject.Find("GroupDropdown");

        // Get index of selected option
        int index = dropdownMenu.GetComponent<Dropdown>().value;

        // Get all available options in dropdown menu
        List<Dropdown.OptionData> options = dropdownMenu.GetComponent<Dropdown>().options;

        // Get string value at selected index, and set group filter
        if (options[index].text != null)
        {
            StaticVariableHolder.filterByGroup = options[index].text;
        }
    }

    // Procedure to load updated list of custom quizzes, using search query strings
    public void Search()
    {
        if (topicSearchStr != null)
        {
            StaticVariableHolder.searchByTopicSubject = topicSearchStr.text;
        }
        if (uploaderSearchStr != null)
        {
            StaticVariableHolder.searchByUser = uploaderSearchStr.text;
        }
        if (topicSearchStr != null || uploaderSearchStr != null)
        {
            // Fade into updated list of custom quizzes
            Initiate.Fade("CustomQuizzes", Color.black, 4.0f);
        } else
        {
            // If user did not enter a topic and/or uploader search string, display error message
            if (!EditorUtility.DisplayDialog("Error searching custom quizzes",
                                    "Please enter a topic search string and/or uploader search string.",
                                    "OK", "Cancel"))
            {
                // If user cancels search, return to default list of custom quizzes
                SceneManager.LoadScene("CustomQuizzes");
            }
        }

    }
}
#endif