Read Me

Simple Scene Fade Load System

Setting Up ->

1 = Go to "File->Build Settings" now add all the scenes that you want to load using the fade system
2 = Now from anywhere in the game call "Initiate.Fade(sceneName,loadToColor,speed);
"
where sceneName is the name of scene that you want to load of type string,
loadToColor is the color you want to fade away with of type Color and
speed is of type float variable which decides the speed of transition.

That's it just one line of code and you are ready to fade away

if you still dont understand then take a look at the demo scene and DemoScript all code is well commented

Thank You
FlatTutorials