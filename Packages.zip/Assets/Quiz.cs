﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to handle the starting and playing of quizzes
public class Quiz : MonoBehaviour
{
    // Procedure to load quiz from clicked button on main menu
	public void StartQuiz(int buttonNum)
	{
        // Find topic list component on main menu
        var topicMenu = GameObject.Find("TopicList").GetComponent<Canvas>();
        // Get name of topic from clicked button
        string topicName = topicMenu.GetComponentsInChildren<Button>()[buttonNum - 1].GetComponentInChildren<Text>().text;

        // Query database for topic ID, and to check the quiz exists
        string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "ti", "\"" + topicName.ToString() };
        List<string> results = Python.RunPython(args);

        string topicExists = results[1];
        if (topicExists == "0")
        {
            // If topic does not exist (yet), display error message
            if (!EditorUtility.DisplayDialog("Error",
        "Sorry, that quiz does not exist. Please try another sample quiz, or view the custom quizzes uploaded by the community!",
        "OK", "Custom Quizzes"))
            {
                // If user chooses to view custom quizzes instead, load list of custom quizzes
                SceneManager.LoadScene("CustomQuizzes");
            }
            else
            {
                // Otherwise, return to main menu, so the user can choose another sample quiz
                SceneManager.LoadScene("MainMenu");
            }
        }

        // If topic does exist, set static variables for topic ID, topic name and question number (start with question 1)
        StaticVariableHolder.topicID = Convert.ToInt32(results[0]);
        StaticVariableHolder.topic = topicName;
        StaticVariableHolder.questionNum = 1;

        // Fade into screen for first quiz question
        Initiate.Fade("Quiz", Color.black, 4.0f);
	}

    // Procedure to start custom quiz from entered topic ID
    public void StartCustomQuiz(InputField topicID)
    {
        try
        {
            // Query database for name of custom topic from its ID
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "ctn", topicID.text };
            List<string> results = Python.RunPython(args);

           // Set static variable to enter custom quiz mode (so the system knows it is loading a custom quiz and not a sample one)
            StaticVariableHolder.custom = true;
            // Set static variables for topic ID, topic name and question number (start with question 1)
            StaticVariableHolder.topicID = Int32.Parse(topicID.text);
            StaticVariableHolder.topic = results[0];
            StaticVariableHolder.questionNum = 1;

            // Fade into screen for first custom quiz question
            Initiate.Fade("Quiz", Color.black, 4.0f);
        }
        catch
        {
            // If an error occurs due to the custom topic not existing (a database inconsistency), display error message
            if (!EditorUtility.DisplayDialog("Error",
        "Sorry, that quiz does not exist. Please try another custom quiz, or create a new quiz!",
        "OK", "Create Quiz"))
            {
                // If user chooses to make their own custom quiz, begin quiz creation process
                SceneManager.LoadScene("StartQuizCreation");
            }
            else
            {
                // Otherwise, return to list of custom quizzes, so the user can try another one
                SceneManager.LoadScene("CustomQuizzes");
            }
        }       
    }

    // Procedure to replay quiz after finishing one
    public void RepeatQuiz()
    {
        // Reset question number to 1, and score to 0
        StaticVariableHolder.questionNum = 1;
        StaticVariableHolder.score = 0;

        // Fade into screen for first quiz question
        Initiate.Fade("Quiz", Color.black, 4.0f);
    }

    // Procedure to start random sample quiz
    public void StartRandomQuiz()
    {
        // Boolean variable for whether a valid topic (that exists) has been chosen
        Boolean validTopic = false;
        // Loop until a valid topic is chosen
        while (!validTopic)
        {
            // Initialise random number generator
            System.Random rand = new System.Random();
            // Get random topic ID between 1 and 90 (as there will be 90 sample topics)
            int topicID = rand.Next(1, 90);

            // Query database for topic name from randomly-chosen ID
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "tn", topicID.ToString() };
            List<string> results = Python.RunPython(args);

            if (results[1] == "1")
            {
                // If topic exists, set static variables for topic ID, topic name and question number (start with question 1)
                StaticVariableHolder.topicID = topicID;
                StaticVariableHolder.topic = results[0];
                StaticVariableHolder.questionNum = 1;

                // Fade into screen for first quiz question
                Initiate.Fade("Quiz", Color.black, 4.0f);
                // Set Boolean variable to true, to end loop
                validTopic = true;
            }
        }
    }

    // Procedure to start recommended quiz, based on topic the user has just completed
    public void StartRecommendedQuiz()
    {
        //If a topic has been completed...
        if (StaticVariableHolder.topicID != 0)
        {
            // Obtain recommendation from Python program, by passing it the user's ID and the ID of the topic they just completed
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\rec_system.py\"", StaticVariableHolder.userID.ToString(), StaticVariableHolder.topicID.ToString() };
            List<string> results = Python.RunPython(args);

            // Check that a topic ID was successfully provided
            int recommendedTopicID = Int32.Parse(results[0]);

            // Query database for topic name from ID
            string[] args2 = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "tn", recommendedTopicID.ToString() };
            results = Python.RunPython(args2);

            if (results[1] == "1")
            {
                // If topic exists, set static variables for topic ID, topic name and question number (start with question 1)
                StaticVariableHolder.topicID = recommendedTopicID;
                StaticVariableHolder.topic = results[0];
                StaticVariableHolder.questionNum = 1;

                // Fade into screen for first quiz question
                Initiate.Fade("Quiz", Color.black, 4.0f);
            } else
            {
                // Otherwise, display error message (as the recommended quiz has not been created yet)
                if (!EditorUtility.DisplayDialog("Error recommending quiz",
        "Sorry, the quiz we would recommend does not exist yet. You may stay on this results page, or view your other recommendations.",
        "Stay", "View Recommendations"))
                {
                    // If they choose to view their other recommendations, load them for the user to flick through...
                    SceneManager.LoadScene("TopicRecommendations");
                }
            }
        }
    }

    // Procedure to load the next question, or end the quiz once all 10 questions have been completed
    public void NextQuestion(int answerNum)
    {
        // Get user's answer from clicked button
        string answer = GameObject.Find("Answer" + answerNum.ToString()).GetComponentInChildren<Text>().text;
        if (answer == StaticVariableHolder.correctAnswer)
        {
            // If user answered correctly, increment their score on this quiz
            StaticVariableHolder.score += 1;
        }

        if (StaticVariableHolder.questionNum == 10)
        {
            if (StaticVariableHolder.custom == false)
            {
                // If user has completed all 10 questions, and this is a sample quiz (not a custom one), load the imaginative exercise...
                Initiate.Fade("ImaginativeExercise", Color.black, 4.0f);
            } else
            {
                // Otherwise, if user has completed all questions, and this is a custom quiz, load their results...
                Initiate.Fade("Results", Color.black, 4.0f);
            }
        }
        else
        {
            // If they have not yet completed all 10 questions, increment question number and load screen for next question
            StaticVariableHolder.questionNum += 1;
            SceneManager.LoadScene("Quiz");
        }
    }
}
#endif