﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Class to rotate Earth graphic on main menu
public class RotateGlobe : MonoBehaviour {	
	// Call update once per frame, to rotate globe at a suitable speed
	void Update () {
        transform.Rotate(0, 0.25f, 0);
	}
}
