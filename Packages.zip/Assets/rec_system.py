import sys
import os
import csv
import MySQLdb
import random
from datetime import datetime

# Open connection to database
db = MySQLdb.connect(host="localhost",    # Host
                     user="master",       # Username
                     passwd="toclafane",  # Password
                     db="infinityowldb")    # Database Name

# Create cursor object to execute queries
cur = db.cursor()

# Function to analyse performance trend of last 3 scores on topic
def get_trend(scores):
	if max(scores) < 4:
		trend = 1 # Poor performance
	elif max(scores) >= 4 and max(scores) < 7:
		trend = 2 # Mediocre performance
	elif max(scores) >= 7 and max(scores) < 10:
		trend = 3 # Good performance
	elif max(scores) == 10:
		trend = 4 # Has obtained perfect score on quiz
	else:
		trend = 0
	
	try:
		if max(scores) != 10 and scores[0] > scores[1] and scores[1] > scores[2]:
			trend = 5 # User showing improvement over last 3 attempts, but has not obtained perfect score yet
	except:
		pass
	return trend
		
# Function to make topic recommendation by following algorithm
def recommend_topic(user_id, topic_id):
	# Get name of current topic
	sql = "SELECT TopicName FROM Topics WHERE TopicID=" + str(topic_id) + ";"
	cur.execute(sql)
	topic_name = None
	for row in cur.fetchall():
		topic_name = row[0]

	# Get difficulty of current topic
	sql = "SELECT Difficulty FROM Topics WHERE TopicID=" + str(topic_id) + ";"
	cur.execute(sql)
	difficulty1 = 0
	for row in cur.fetchall():
			difficulty1 = row[0]

	# Get scores for current topic
	sql = "SELECT score FROM scores WHERE userid=" + str(user_id) + " AND topicid=" + str(topic_id) + " ORDER BY datetime DESC;"
	cur.execute(sql)

	# Get last 3 scores for topic
	scores = []
	for row in cur.fetchall():
		scores.append(row[0])
		if len(scores) == 3:
			break
	
	# If scores array is empty, add 0 to it
	if not scores:
		scores.append(0)
	
	# Get user's performance trend on current topic
	trend = get_trend(scores)
	
	# Get all completed quizzes, and sort in descending order of score
	cur.execute("SELECT topicid FROM scores WHERE userid=" + sys.argv[1] + " ORDER BY score DESC;")

	# Get 5 topics that the user has performed best in
	top_topics = []
	for row in cur.fetchall():
		if not (row[0] in top_topics):
			top_topics.append(row[0])
		if len(top_topics) == 5:
			break
		
	# Read similarity scores between this topic and all other topics, from adjacency matrix, and add to array
	topic_relations = []
	with open('topic_relations.csv', 'rb') as csvfile:
		reader = csv.reader(csvfile, delimiter = ',', quotechar='|')
		for row in reader:
			if row[0] == topic_name:
				for i in range(1, len(row)):
					topic_relations.append([str(i), row[i]])
				
	# Create empty array of potential topics for recommendation
	potential_topics = []
	
	# Iterate through all topic relationships
	for i in range(0, len(topic_relations)):
			# Get difficulty of related topic
			sql = "SELECT difficulty FROM topics WHERE topicid=" + topic_relations[i][0] + ";"
			cur.execute(sql)
			difficulty2 = 0
			for row in cur.fetchall():
				difficulty2 = row[0]
			
			# Calculate difference in difficulty between current topic and related topic
			difficulty_difference = difficulty2 - difficulty1
			# e.g. 3 (hard) - 1 (easy) = 2 => Considerably harder
			# e.g. 2 (medium) - 3 (hard) = -1 => Slightly easier
			
			# Add topic to array of potential topics, if it meets criteria for user's performance trend
			if trend == 1:
					# If topic is slightly easier, and quite/very similar, add to list of potential topics
					if difficulty_difference == -1 and int(topic_relations[i][1]) >= 2:
							potential_topics.append(topic_relations[i][0])
					# If topic is the same difficulty (easy), and quite/very similar, add to list of potential topics
					elif difficulty_difference == 0 and difficulty1 == 1 and int(topic_relations[i][1]) >= 2:
							potential_topics.append(topic_relations[i][0])
			elif trend == 2:
					# If topic is the same difficulty, and quite/very similar, add to list of potential topics
					if difficulty_difference == 0 and int(topic_relations[i][1]) >= 2:
							potential_topics.append(topic_relations[i][0])
			elif trend == 3:
					# If topic is slightly harder, and quite/very similar, add to list of potential topics
					if difficulty_difference == 1 and int(topic_relations[i][1]) >= 2:
							potential_topics.append(topic_relations[i][0])
			elif trend == 4:
					# If topic is much harder, but very similar, add to list of potential topics
					if difficulty_difference == 2 and int(topic_relations[i][1]) == 3:
							potential_topics.append(topic_relations[i][0])
					# If topic is the same difficulty, but not very similar, add to list of potential topics
					elif difficulty_difference == 0 and int(topic_relations[i][1]) == 1:
							potential_topics.append(topic_relations[i][0])
			elif trend == 5:
					# If topic is slightly harder, and very similar, add to potential topics
					if difficulty_difference == 1 and int(topic_relations[i][1]) == 3:
							potential_topics.append(topic_relations[i][0])
					# If topic is the same difficulty, and quite similar, add to potential topics
					elif difficulty_difference == 0 and int(topic_relations[i][1]) == 2:
							potential_topics.append(topic_relations[i][0])

	# P(A) = Sum(P(A|B))
	# Initialise array of probabilities that each potential topic will be recommended
	probabilities = []
	# Iterate through all potential topics
	for topicA in potential_topics:
		# Initialise probability P(A) to 0
		probability = 0
		# Iterate through topics user has performed well in
		for topicB in top_topics:
			# If potential topic is not one that user has performed well in
			if topicA != topicB:
				# Read similarity scores for potential topic, from adjacency matrix
				with open('topic_relations.csv', 'rb') as csvfile:
					reader = csv.reader(csvfile, delimiter = ',', quotechar='|')
					i = 0
					for row in reader:
						if i == int(topicA):
							# Add to P(A) the probability P(A|B), which is set depending on similarity between topic A and topic B
							if int(row[topicB]) == 1:
									probAgivenB = 0.05	# P(High Performance in Topic A | Low Similarity to Topic B) = 0.25
									probability += probAgivenB
							elif int(row[topicB]) == 2:
									probAgivenB = 0.1	# P(High Performance in Topic A | Medium Similarity to Topic B) = 0.5
									probability += probAgivenB
							elif int(row[topicB]) == 3:
									probAgivenB = 0.15	# P(High Performance in Topic A | High Similarity to Topic B) = 0.75
									probability += probAgivenB
						i += 1
		# Add potential topic A and its probability P(A) to array of probabilities
		probabilities.append([topicA, probability])
	
	# Get topics with maximum and minimum probabilities from array, and add to array (there may be more than one topic with equal probability)
	max_p = 0
	min_p = 1
	max_probs = []
	min_probs = []
	for p in probabilities:
		if p[1] < min_p:
			min_p = p[1]
			min_probs = [p]
		elif p[1] == min_p:
			min_probs.append(p)
		if p[1] > max_p:
			max_p = p[1]
			max_probs = [p]
		elif p[1] == max_p:
			max_probs.append(p)
			
	# If no topic recommendation has been generated, return None
	if not max_probs:
		return None
	
	# Generate random seed from current date and time
	random.seed(datetime.now())
	
	# If there is a trend, but it is not perfect, make random choice between topics with maximum probabilities to recommend
	if trend != 0 and trend != 4:
		topic = random.choice(max_probs)
	# If user has perfect trend on current topic, either recommend topic with maximum probability, or topic with minimum probability (for something completely different!)
	elif trend == 4:
		rand = random.choice([True, False])
		if rand == True:
			topic = random.choice(max_probs)
		else:
			topic = random.choice(min_probs)
	else:
		topic_id = None

	# Get name of recommended topic
	topicname = None
	sql = "SELECT topicname FROM topics WHERE topicid=" + topic[0] + ";"
	cur.execute(sql)
	for row in cur.fetchall():
		topic_name = row[0]
			
	# Return recommendation, including topic's ID, probability and name, along with trend for current topic
	topic.append(topic_name)
	topic.append(trend)
	return topic

# MAIN PROGRAM
# Since we are calling the program from Unity, we need to change directory
os.chdir('./Assets')

topic_id = 0
# Get topic ID from command line argument, if possible
try:
	topic_id = sys.argv[2]
except:
	pass

# If topic ID was provided, call function to make topic recommendation based on it
if topic_id != 0:
	rec = recommend_topic(sys.argv[1], sys.argv[2])
	# Output ID of recommended topic!
	print str(rec[0])
# If topic ID was not provided as command line argument...
else:
	# Initialise array of recommendations
	recs = []
	# Get all distinct topic IDs for topics that the user has completed, using user's ID from command line argument
	cur.execute("SELECT DISTINCT TopicID FROM Scores WHERE UserID=" + str(sys.argv[1]) + ";")
	# Iterate through all completed topics, making recommendation for each, and adding to array of recommendations
	for row in cur.fetchall():
		rec = recommend_topic(sys.argv[1], row[0])
		if rec != None:
			recs.append([row[0], rec])
	# Sort recommendations in ascending order of probability
	recs.sort(key=lambda r: r[1][1])
	# Reverse array of recommendations, so that those topics with the highest probabilities come first
	recs.reverse()
	
	# Initialise array to store topics that have been recommended
	recommended = []
	# Iterate through all topic recommendations
	for r in recs:
		# Get name of topic the recommendation is based on
		cur.execute("SELECT TopicName FROM Topics WHERE TopicID=" + str(r[0]) + ";")
		for row in cur.fetchall():
			r[0] = row[0]	
		# If recommended topic is not the same as the topic the recommendation was based on, output recommendation (including information to give reason)
		if r[1][2] != r[0] and (r[1][2] not in recommended):
			# Recommend topic X with probability P, based on topic Y with trend T
			print str(r[1][0]) + "," + str(r[1][2]) + "," + str(r[1][1]) + "," + str(r[0]) + "," + str(r[1][3])
		# Add recommended topic to array of topics that have already been recommended
		recommended.append(r[1][2])
		
		
		
