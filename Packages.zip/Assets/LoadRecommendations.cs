﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;

// Class to load list of topic recommendations and let the user choose between them
public class LoadRecommendations : MonoBehaviour
{
    // Store list of recommendations, and number of recommendation currently being displayed
    int recNumber;
    List<string[]> recs;

    // This procedure is run on initialisation
    void Start()
    {
        try
        {
            // Generate topic recommendations based on user's performance, and load into list
            recs = new List<string[]>();
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\rec_system.py\"", StaticVariableHolder.userID.ToString() };
            List<string> results = Python.RunPython(args);
            
            for (int i = 0; i < results.Count; i++)
            {
                string[] rec = results[i].Split(',');
                recs.Add(rec);
            }

            // Show first recommendation
            recNumber = 0;
            ShowMessage();           
        } catch
        {
            // If the system is unable to generate recommendations, display error message
            if (!EditorUtility.DisplayDialog("Error recommending quiz",
                        "You need to complete more quizzes before we can make a recommendation! You could always try a random quiz topic instead?",
                        "Back to Main Menu", "Random Quiz"))
            {
                // If user chooses to try a random quiz...
                StartRandomQuiz();
            } else
            {
                // Otherwise, return user to main menu
                SceneManager.LoadScene("MainMenu");
            }
        }        
    }

    // Procedure to start recommended quiz
    public void StartQuiz()
    {
        // Set static variables for topic ID, topic name and question number (start with question 1)
        StaticVariableHolder.topicID = Int32.Parse(recs[recNumber][0]);
        StaticVariableHolder.topic = recs[recNumber][1];
        StaticVariableHolder.questionNum = 1;

        // Fade into screen for first quiz question
        Initiate.Fade("Quiz", Color.black, 4.0f);
    }

    // Procedure to flick to next recommended topic
    public void NextRecommendation()
    {
        // Increment recommendation number
        recNumber++;
        if (recNumber < recs.Count)
        {
            // If recommendation number is less than total number of recommended topics, display recommendation
            ShowMessage();
        } else
        {
            // Otherwise, return to main menu
            Initiate.Fade("MainMenu", Color.black, 4.0f);
        }
    }

    // Procedure to show recommendation message
    private void ShowMessage()
    {
        // Set contents of message, based on user's performance in the original topic on which the recommendation was based...
        string message = "";
        if (recs[recNumber][4] == "1")
        {
            message = "You didn't do so well in '" + recs[recNumber][3] + "'. ";
        }
        else if (recs[recNumber][4] == "2")
        {
            message = "You did OK in '" + recs[recNumber][3] + "'. ";
        }
        else if (recs[recNumber][4] == "3")
        {
            message = "You did well in '" + recs[recNumber][3] + "'. ";
        }
        else if (recs[recNumber][4] == "4")
        {
            message = "You got a perfect score in '" + recs[recNumber][3] + "'. ";
        }
        else if (recs[recNumber][4] == "5")
        {
            message = "You seem to be improving in '" + recs[recNumber][3] + "'. ";
        }
        message += "Why not try the topic '" + recs[recNumber][1] + "'?";

        // Display recommendation message
        GameObject.Find("RecommendationText").GetComponentInChildren<Text>().text = message;
    }

    // Procedure to start random sample quiz
    private void StartRandomQuiz()
    {
        // Boolean variable for whether a valid topic (that exists) has been chosen
        Boolean validTopic = false;
        // Loop until a valid topic is chosen
        while (!validTopic)
        {
            // Initialise random number generator
            System.Random rand = new System.Random();
            // Get random topic ID between 1 and 90 (as there will be 90 sample topics)
            int topicID = rand.Next(1, 90);

            // Query database for topic name from randomly-chosen ID
            string[] args = { "\"C:\\Users\\darth\\Documents\\Computer Science\\Unity\\Prototype\\Assets\\db_access.py\"", "tn", topicID.ToString() };
            List<string> results = Python.RunPython(args);

            if (results[1] == "1")
            {
                // If topic exists, set static variables for topic ID, topic name and question number (start with question 1)
                StaticVariableHolder.topicID = topicID;
                StaticVariableHolder.topic = results[0];
                StaticVariableHolder.questionNum = 1;

                // Fade into screen for first quiz question
                SceneManager.LoadScene("Quiz");
                // Set Boolean variable to true, to end loop
                validTopic = true;
            }
        }
    }
}
#endif