/*DROP DATABASE InfinityOwlDB;*/

CREATE DATABASE IF NOT EXISTS InfinityOwlDB;

USE InfinityOwlDB;

CREATE TABLE IF NOT EXISTS Users (
	UserID		INT				NOT NULL		auto_increment,
	Username	VARCHAR(20)		NOT NULL,
	Password	VARCHAR(20)		NOT NULL,
	FirstName	VARCHAR(50)		NOT NULL,
	Surname		VARCHAR(50)		NOT NULL,	
	OwlColour	VARCHAR(10)		NOT NULL,
	Level		INT				NOT NULL,
	XP			INT				NOT NULL,
	PRIMARY KEY(UserID)
);

CREATE TABLE IF NOT EXISTS UserGroups (
	GroupID			INT				NOT NULL		auto_increment,
	GroupName		VARCHAR(20)		NOT NULL,
	Password		VARCHAR(20)		NOT NULL,
	AdminID			INT				NOT NULL,
    TopicUnlock 	VARCHAR(20),
    Deadline		DATETIME,
	PRIMARY KEY(GroupID)
);

CREATE TABLE IF NOT EXISTS GroupMembers (
	UserID		INT			NOT NULL,
	GroupID		INT			NOT NULL,
	PRIMARY KEY(UserID, GroupID)
);

CREATE TABLE IF NOT EXISTS Messages (
	MessageID		INT				NOT NULL	auto_increment,
    SenderID		INT				NOT NULL,
    Receivers		VARCHAR(100)	NOT NULL,
    MessageSubject	VARCHAR(100)	NOT NULL,
    MessageText		VARCHAR(1000)	NOT NULL,
    SendDateTime	DATETIME		NOT NULL,
    PRIMARY KEY(MessageID)
);


CREATE TABLE IF NOT EXISTS Topics (
	TopicID					INT				NOT NULL		auto_increment,
	TopicName				VARCHAR(40)		NOT NULL,
	Category				VARCHAR(20)		NOT NULL,
	Difficulty				INT				NOT NULL,
	UploaderID				INT				NOT NULL,
	UploadDateTime			DATETIME		NOT NULL,
    ImaginativeExercise		VARCHAR(200),
	Approved				BOOLEAN			NOT NULL,
	PRIMARY KEY(TopicID)
);

CREATE TABLE IF NOT EXISTS Questions (
	TopicID			INT				NOT NULL,
	QuestionNum		INT				NOT NULL,
	Question		VARCHAR(200)	NOT NULL,
	Answer1			VARCHAR(100)	NOT NULL,
	Answer2			VARCHAR(100)	NOT NULL,
	Answer3			VARCHAR(100)	NOT NULL,
	CorrectAnswer	VARCHAR(100)	NOT NULL	
    CHECK(CorrectAnswer = Answer1 OR CorrectAnswer = Answer2 OR CorrectAnswer = Answer3),
	ImagePath		VARCHAR(100)	NOT NULL,
	PRIMARY KEY(TopicID, QuestionNum)
);

CREATE TABLE IF NOT EXISTS Scores (
	UserID			INT			NOT NULL,
	TopicID			INT			NOT NULL,
	AttemptNumber	INT			NOT NULL,
	Score			INT			NOT NULL,
	DateTime		DATETIME	NOT NULL,
	PRIMARY KEY(UserID, TopicID, AttemptNumber)
);

CREATE TABLE IF NOT EXISTS ImaginativeResponses (
	UserID				INT				NOT NULL,
	TopicID				INT				NOT NULL,
	SubmissionNumber	INT				NOT NULL,
    Response			VARCHAR(1000)	NOT NULL,
	DateTime			DATETIME		NOT NULL,
	PRIMARY KEY(UserID, TopicID, SubmissionNumber)
);

CREATE TABLE IF NOT EXISTS CustomTopics (
	TopicID			INT				NOT NULL		auto_increment,
	TopicName		VARCHAR(40)		NOT NULL,
	UploaderID		INT				NOT NULL,
	UploadDateTime	DATETIME		NOT NULL,
	Approved		BOOLEAN			NOT NULL,
	PRIMARY KEY(TopicID)
);

CREATE TABLE IF NOT EXISTS CustomQuestions (
	TopicID			INT				NOT NULL,
	QuestionNum		INT				NOT NULL,
	Question		VARCHAR(200)	NOT NULL,
	Answer1			VARCHAR(100)	NOT NULL,
	Answer2			VARCHAR(100)	NOT NULL,
	Answer3			VARCHAR(100)	NOT NULL,
	CorrectAnswer	VARCHAR(100)	NOT NULL	
    CHECK(CorrectAnswer = Answer1 OR CorrectAnswer = Answer2 OR CorrectAnswer = Answer3),
	ImagePath		VARCHAR(100)	NOT NULL,
	PRIMARY KEY(TopicID, QuestionNum)
);

CREATE TABLE IF NOT EXISTS CustomScores (
	UserID			INT			NOT NULL,
	TopicID			INT			NOT NULL,
	AttemptNumber	INT			NOT NULL,
	Score			INT			NOT NULL,
	DateTime		DATETIME	NOT NULL,
	PRIMARY KEY(UserID, TopicID, AttemptNumber)
);


