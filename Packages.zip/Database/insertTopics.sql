USE InfinityOwlDB;

DROP TABLE Topics;

CREATE TABLE IF NOT EXISTS Topics (
	TopicID					INT				NOT NULL		auto_increment,
	TopicName				VARCHAR(40)		NOT NULL,
	Category				VARCHAR(20)		NOT NULL,
	Difficulty				INT				NOT NULL,
	UploaderID				INT				NOT NULL,
	UploadDateTime			DATETIME		NOT NULL,
    ImaginativeExercise		VARCHAR(200),
	Approved				BOOLEAN			NOT NULL,
	PRIMARY KEY(TopicID)
);

DROP TABLE ImaginativeResponses;

CREATE TABLE IF NOT EXISTS ImaginativeResponses (
	UserID				INT				NOT NULL,
	TopicID				INT				NOT NULL,
	SubmissionNumber	INT				NOT NULL,
    Response			VARCHAR(1000)	NOT NULL,
	DateTime			DATETIME		NOT NULL,
	PRIMARY KEY(UserID, TopicID, SubmissionNumber)
);

# Astronomy Topics
INSERT INTO Topics VALUES(NULL, 'The Universe', 'Astronomy', 1, 1, '2018-12-12', 'How do you think the universe began? Or has it always been here?', 1);
INSERT INTO Topics VALUES(NULL, 'Our Solar System', 'Astronomy', 1, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'The Sun and Moon', 'Astronomy', 1, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Stars', 'Astronomy', 2, 1, '2018-12-12', 'Do you think humans will ever become a space-faring civilisation, and colonise the stars?', 1);
INSERT INTO Topics VALUES(NULL, 'Planets', 'Astronomy', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Asteroids and Comets', 'Astronomy', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Galaxies', 'Astronomy', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Space and Time', 'Astronomy', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Black Holes', 'Astronomy', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'The Big Bang', 'Astronomy', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'The Expanding Universe', 'Astronomy', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Space Observation', 'Astronomy', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Space Exploration', 'Astronomy', 4, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Time Travel', 'Astronomy', 4, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Existence', 'Astronomy', 4, 1, '2018-12-12', NULL, 0);

# Physics Topics
INSERT INTO Topics VALUES(NULL, 'Matter and Energy', 'Physics', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Temperature', 'Physics', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Forces', 'Physics', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Friction and Resistance', 'Physics', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Electricity', 'Physics', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Magnetism', 'Physics', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Gravity', 'Physics', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Light and Dark', 'Physics', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Sound and Vibration', 'Physics', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Electromagnetic Spectrum', 'Physics', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'The Greenhouse Effect', 'Physics', 3, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Renewable Energy', 'Physics', 3, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Splitting the Atom', 'Physics', 4, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Radioactivity', 'Physics', 4, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'A Theory of Everything', 'Physics', 4, 1, '2018-12-12', NULL, 0);

# Chemistry Topics
INSERT INTO Topics VALUES(NULL, 'Atoms and Molecules', 'Chemistry', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Elements and Compounds', 'Chemistry', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Solids, Liquids and Gases', 'Chemistry', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Water', 'Chemistry', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Rocks and Soils', 'Chemistry', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Metals and Alloys', 'Chemistry', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Acids and Bases', 'Chemistry', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Solutions and Mixtures', 'Chemistry', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Chemical Reactions', 'Chemistry', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'The Primordial Soup', 'Chemistry', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'The Atmosphere', 'Chemistry', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'The Carbon Cycle', 'Chemistry', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Pollution', 'Chemistry', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Colonising Mars', 'Chemistry', 4, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'The Periodic Table', 'Chemistry', 4, 1, '2018-12-12', NULL, 0);

# Biology Topics
INSERT INTO Topics VALUES(NULL, 'Origins of Life', 'Biology', 1, 1, '2018-12-12', 'How do you think life began on Earth?', 1);
INSERT INTO Topics VALUES(NULL, 'Organisms', 'Biology', 1, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Micro-Organisms', 'Biology', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Plants', 'Biology', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Animals', 'Biology', 1, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Arthropods', 'Biology', 2, 1, '2018-12-1', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Dinosaurs', 'Biology', 2, 1, '2018-12-12', 'If you were a dinosaur, what would you be? And what would life have been like in the prehistoric world?', 1);
INSERT INTO Topics VALUES(NULL, 'Mammals and Birds', 'Biology', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Marine Life', 'Biology', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Adaptation', 'Biology', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Genes and Inheritance', 'Biology', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Evolution', 'Biology', 3, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Classification', 'Biology', 4, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Brain and Mind', 'Biology', 4, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Alien Life', 'Biology', 4, 1, '2018-12-12', NULL, 0);

# Geography Topics
INSERT INTO Topics VALUES(NULL, 'Planet Earth', 'Geography', 1, 1, '2018-12-12', 'How would you describe our planet to an alien visitor?', 1);
INSERT INTO Topics VALUES(NULL, 'Continents and Oceans', 'Geography', 1, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Weather Systems', 'Geography', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Biomes', 'Geography', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'The Coast', 'Geography', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Mountains', 'Geography', 2, 1, '2018-12-12', 'Would you like to live in the mountains? Why or why not?', 1);
INSERT INTO Topics VALUES(NULL, 'Rivers', 'Geography', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Rainforests and Deserts', 'Geography', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Polar Regions', 'Geography', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Wonders of the World', 'Geography', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Tectonics', 'Geography', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Natural Disasters', 'Geography', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Climate Change', 'Geography', 3, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Population Problems', 'Geography', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Sustainable Development', 'Geography', 4, 1, '2018-12-12', NULL, 0);

# History Topics
INSERT INTO Topics VALUES(NULL, 'Prehistoric Man', 'History', 1, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Homo Sapiens', 'History', 1, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Agriculture', 'History', 1, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Ancient Civilisations', 'History', 2, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'The Roman Empire', 'History', 2, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Gods and Demigods', 'History', 2, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Western Religions', 'History', 2, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'Eastern Religions', 'History', 2, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'The Dark Ages', 'History', 2, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'The Renaissance', 'History', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'The Age of Exploration', 'History', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'The Industrial Revolution', 'History', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'World Wars', 'History', 3, 1, '2018-12-12', NULL, 0);
INSERT INTO Topics VALUES(NULL, 'Artificial Intelligence', 'History', 4, 1, '2018-12-12', NULL, 1);
INSERT INTO Topics VALUES(NULL, 'The Fate of Humanity', 'History', 4, 1, '2018-12-12', NULL, 0);